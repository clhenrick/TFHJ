# Cividesk sync for Google Apps

This CiviCRM extension syncs the contacts in CiviCRM with the Contacts Directory in Google Apps.

Per Google's restrictions, this extension can only work with Google Apps for Business or Education accounts. If you do have a free Google Apps account, you will need to upgrade.

Please use the 'Administer / System Settings / Cividesk sync for Google Apps' menu to configure this extension once installed.
