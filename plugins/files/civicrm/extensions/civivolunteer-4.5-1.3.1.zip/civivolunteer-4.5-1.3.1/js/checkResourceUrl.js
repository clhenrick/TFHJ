// http://civicrm.org/licensing
window.civiVolunteerResourceUrlIsOk = true;
