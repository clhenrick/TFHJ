<?php
return array(
  array(
    'CRM_HRReport_Form_Contact_HRDetail',
    array(
      'fields' => array(
        'sort_name',
        'email',
        'hrjob_position',
        'hrjob_title',
        'manager',
        'hrjob_level_type',
        'state_province_id',
        'country_id',
      ),
    ),
    'fixtures/dataset-detail.sql',
    'fixtures/detail-alljobs.csv',
  )
);
