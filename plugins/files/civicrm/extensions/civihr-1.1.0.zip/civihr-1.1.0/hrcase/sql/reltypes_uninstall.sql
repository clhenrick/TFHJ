DELETE FROM `civicrm_relationship_type` WHERE name_a_b = 'HR Manager is';
DELETE FROM `civicrm_relationship_type` WHERE name_a_b = 'Recruiting Manager is';
DELETE FROM `civicrm_relationship_type` WHERE name_a_b = 'Line Manager is';

