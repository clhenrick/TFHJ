CiviHR is a collection of extensions defining a human-resources application
that runs on top of the CiviCRM platform.

See also:
 * Install: [doc/INSTALL.md](doc/INSTALL.md)
 * Upgrade: [doc/UPGRADE.md](doc/UPGRADE.md)
 * Develop (install, test, etc): [doc/DEVELOP.md](doc/DEVELOP.md)
 * Wiki: http://wiki.civicrm.org/confluence/display/CRM/CiviHR
 * Issues: http://issues.civicrm.org/jira/secure/Dashboard.jspa?selectPageId=11213
