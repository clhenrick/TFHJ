<?php
// This file declares a managed database record of type "ReportTemplate".
// The record will be automatically inserted, updated, or deleted from the
// database as appropriate. For more details, see "hook_civicrm_managed" at:
// http://wiki.civicrm.org/confluence/display/CRMDOC42/Hook+Reference
return array (
  0 =>
  array (
    'name' => 'Contributions with Price Set Data',
    'entity' => 'ReportTemplate',
    'params' =>
    array (
      'version' => 3,
      'label' => 'Contributions with Price Set data',
      'description' => 'Line item Report (based on contributions) (nz.co.fuzion.extendedreport)',
      'class_name' => 'CRM_Extendedreport_Form_Report_Price_Contributionbased',
      'report_url' => 'price/contributionbased',
      'component' => 'CiviContribute',
    ),
  ),
);