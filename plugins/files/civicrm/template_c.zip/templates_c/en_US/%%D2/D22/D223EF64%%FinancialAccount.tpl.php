<?php /* Smarty version 2.6.27, created on 2014-08-01 11:17:05
         compiled from CRM/Financial/Form/FinancialAccount.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Financial/Form/FinancialAccount.tpl', 1, false),array('block', 'ts', 'CRM/Financial/Form/FinancialAccount.tpl', 27, false),array('function', 'help', 'CRM/Financial/Form/FinancialAccount.tpl', 46, false),array('function', 'crmSetting', 'CRM/Financial/Form/FinancialAccount.tpl', 108, false),array('function', 'crmURL', 'CRM/Financial/Form/FinancialAccount.tpl', 121, false),array('modifier', 'crmReplace', 'CRM/Financial/Form/FinancialAccount.tpl', 47, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><h3><?php if ($this->_tpl_vars['action'] == 1): ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>New Financial Account<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php elseif ($this->_tpl_vars['action'] == 2): ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Edit Financial Account<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php else: ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Delete Financial Account<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php endif; ?></h3>
<div class="crm-block crm-form-block crm-contribution_type-form-block crm-financial_type-form-block">
<?php if ($this->_tpl_vars['action'] == 8): ?>
  <div class="messages status no-popup">
    <div class="icon inform-icon"></div>
    <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>WARNING: You cannot delete a <?php echo $this->_tpl_vars['delName']; ?>
 Financial Account if it is currently used by any Financial Types. Consider disabling this option instead.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Deleting a financial type cannot be undone.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Do you want to continue?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
  </div>
<?php else: ?>
  <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'top')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
  <table class="form-layout-compressed">
    <tr class="crm-contribution-form-block-name">
      <td class="label"><?php echo $this->_tpl_vars['form']['name']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['name']['html']; ?>
</td>
    </tr>
    <tr class="crm-contribution-form-block-description">
      <td class="label"><?php echo $this->_tpl_vars['form']['description']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['description']['html']; ?>
</td>
    </tr>
    <tr class="crm-contribution-form-block-organisation_name">
      <td class="label"><?php echo $this->_tpl_vars['form']['contact_name']['label']; ?>
&nbsp;<?php echo smarty_function_help(array('id' => "id-financial-owner",'file' => "CRM/Contact/Form/Contact.hlp"), $this);?>
</td>
      <td class="html-adjust"><?php echo ((is_array($_tmp=$this->_tpl_vars['form']['contact_name']['html'])) ? $this->_run_mod_handler('crmReplace', true, $_tmp, 'class', 'twenty') : smarty_modifier_crmReplace($_tmp, 'class', 'twenty')); ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use this field to indicate the organization that owns this account.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
    <tr class="crm-contribution-form-block-financial_account_type_id">
      <td class="label"><?php echo $this->_tpl_vars['form']['financial_account_type_id']['label']; ?>
</td>
      <td class="html-adjust"><?php echo ((is_array($_tmp=$this->_tpl_vars['form']['financial_account_type_id']['html'])) ? $this->_run_mod_handler('crmReplace', true, $_tmp, 'class', 'twenty') : smarty_modifier_crmReplace($_tmp, 'class', 'twenty')); ?>
</td>
    </tr>
    <tr class="crm-contribution-form-block-accounting_code">
      <td class="label"><?php echo $this->_tpl_vars['form']['accounting_code']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['accounting_code']['html']; ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Enter the corresponding account code used in your accounting system. This code will be available for contribution export, and included in accounting batch exports.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
    <tr class="crm-contribution-form-block-account_type_code">
      <td class="label"><?php echo $this->_tpl_vars['form']['account_type_code']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['account_type_code']['html']; ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Enter an account type code for this account. Account type codes are required for QuickBooks integration and will be included in all accounting batch exports.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
    <tr class="crm-contribution-form-block-is_deductible">
      <td class="label"><?php echo $this->_tpl_vars['form']['is_deductible']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['is_deductible']['html']; ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Are monies received into this account tax-deductible?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
    <tr class="crm-contribution-form-block-is_active">
      <td class="label"><?php echo $this->_tpl_vars['form']['is_active']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['is_active']['html']; ?>
</td>
    </tr>
    <tr class="crm-contribution-form-block-is_tax">
      <td class="label"><?php echo $this->_tpl_vars['form']['is_tax']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['is_tax']['html']; ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Does this account hold taxes collected? NB: for information only - not used by core CiviCRM.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
    <tr class="crm-contribution-form-block-tax_rate">
      <td class="label"><?php echo $this->_tpl_vars['form']['tax_rate']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['tax_rate']['html']; ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>The default rate used to calculate the taxes collected into this account (e.g. for tax rate of 8.27%, enter 8.27). NB: for information only - not used by core CiviCRM.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
    <tr class="crm-contribution-form-block-is_default">
      <td class="label"><?php echo $this->_tpl_vars['form']['is_default']['label']; ?>
</td>
      <td class="html-adjust"><?php echo $this->_tpl_vars['form']['is_default']['html']; ?>
<br />
        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Is this account to be used as the default account for its financial account type when associating financial accounts with financial types?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
  </table>
<?php endif; ?>
  <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'botttom')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
</div>

<?php echo '
<script type="text/javascript">
var dataUrl        = "'; ?>
<?php echo $this->_tpl_vars['dataURL']; ?>
<?php echo '";
cj(\'#contact_name\').autocomplete( dataUrl, {
  width        : 250,
  selectFirst  : false,
  matchCase    : true,
  matchContains: true,
  max: '; ?>
<?php echo smarty_function_crmSetting(array('name' => 'search_autocomplete_count','group' => 'Search Preferences'), $this);?>
<?php echo '
}).result( function(event, data, formatted) {
  ( parseInt( data[1] ) ) ? cj( "#contact_id" ).val( data[1] ) : cj( "#contact_id" ).val(\'\');
});

// remove current account owner id when current owner removed.
cj("form").submit(function() {
  if (!cj(\'#contact_name\').val()) cj( "#contact_id" ).val(\'\');
});

//current employer default setting
var employerId = "'; ?>
<?php echo $this->_tpl_vars['organisationId']; ?>
<?php echo '";
if ( employerId ) {
  var dataUrl = "'; ?>
<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/ajax/rest','h' => 0,'q' => "className=CRM_Contact_Page_AJAX&fnName=getContactList&json=1&context=contact&org=1&id="), $this);?>
<?php echo '" + employerId ;
  cj.ajax({
    url     : dataUrl,
    async   : false,
    success : function(html){
      //fixme for showing address in div
      htmlText = html.split( \'|\' , 2);
      cj(\'input#contact_name\').val(htmlText[0]);
      cj(\'input#contact_id\').val(htmlText[1]);
    }
  });
}

cj("input#contact_name").click( function( ) {
  cj("input#contact_id").val(\'\');
});
</script>
'; ?>

<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>