<?php /* Smarty version 2.6.27, created on 2014-06-20 10:27:33
         compiled from CRM/Contact/Form/Search/Criteria/Location.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Contact/Form/Search/Criteria/Location.tpl', 1, false),array('block', 'ts', 'CRM/Contact/Form/Search/Criteria/Location.tpl', 33, false),array('modifier', 'crmAddClass', 'CRM/Contact/Form/Search/Criteria/Location.tpl', 40, false),array('modifier', 'replace', 'CRM/Contact/Form/Search/Criteria/Location.tpl', 77, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><div id="location" class="form-item">
    <table class="form-layout">
  <tr>
        <td>
           <?php echo $this->_tpl_vars['form']['location_type']['label']; ?>
<br />
           <?php echo $this->_tpl_vars['form']['location_type']['html']; ?>

           <div class="description" >
             <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Location search uses the PRIMARY location for each contact by default.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><br />
             <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>To search by specific location types (e.g. Home, Work...), check one or more boxes above.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
           </div>
        </td>
        <td colspan="2">
          <div id="streetAddress">
            <?php echo $this->_tpl_vars['form']['street_address']['label']; ?>
<br />
            <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['street_address']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'big') : smarty_modifier_crmAddClass($_tmp, 'big')); ?>

<?php if ($this->_tpl_vars['parseStreetAddress']): ?>
            <br /><a href="#" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use Address Elements<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>" onClick="processAddressFields( 'addressElements' , 1 );return false;"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use Address Elements<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></a>
          </div>
          <div id="addressElements" class=hiddenElement>
            <table class="crm-block crm-form-block advanced-search-address-elements">
          <tr><td><?php echo $this->_tpl_vars['form']['street_number']['label']; ?>
<br /><?php echo $this->_tpl_vars['form']['street_number']['html']; ?>
<br /><span class="description nowrap"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>or ODD / EVEN<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
              <td><?php echo $this->_tpl_vars['form']['street_name']['label']; ?>
<br /><?php echo $this->_tpl_vars['form']['street_name']['html']; ?>
</td>
              <td><?php echo $this->_tpl_vars['form']['street_unit']['label']; ?>
<br /><?php echo ((is_array($_tmp=$this->_tpl_vars['form']['street_unit']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'four') : smarty_modifier_crmAddClass($_tmp, 'four')); ?>
</td>
          </tr>
          <tr>
                <td colspan="3"><a href="#" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use Complete Address<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>" onClick="processAddressFields( 'streetAddress', 1 );return false;"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use Street Address<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></a></td>
            </tr>
            </table>
          </div>
<?php endif; ?>
            <br />
            <?php echo $this->_tpl_vars['form']['city']['label']; ?>
<br />
            <?php echo $this->_tpl_vars['form']['city']['html']; ?>

    </td>
    </tr>

    <tr>
        <td>
        <?php if ($this->_tpl_vars['form']['postal_code']['html']): ?>
    <table class="inner-table">
       <tr>
      <td>
           <?php echo $this->_tpl_vars['form']['postal_code']['label']; ?>
<br />
                             <?php echo $this->_tpl_vars['form']['postal_code']['html']; ?>

      </td>
      <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>OR<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </td>
      <td><label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Postal Code<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label>
        <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['postal_code_low']['label'])) ? $this->_run_mod_handler('replace', true, $_tmp, '-', '<br />') : smarty_modifier_replace($_tmp, '-', '<br />')); ?>

                    &nbsp;&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['form']['postal_code_low']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'six') : smarty_modifier_crmAddClass($_tmp, 'six')); ?>

                                <?php echo $this->_tpl_vars['form']['postal_code_high']['label']; ?>

                    &nbsp;&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['form']['postal_code_high']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'six') : smarty_modifier_crmAddClass($_tmp, 'six')); ?>

      </td>
        </tr>
        <tr>
                            <td colspan="2">&nbsp;</td>
                            <td><?php echo $this->_tpl_vars['form']['prox_distance']['label']; ?>
<br /><?php echo $this->_tpl_vars['form']['prox_distance']['html']; ?>
&nbsp;<?php echo $this->_tpl_vars['form']['prox_distance_unit']['html']; ?>
</td>
                    </tr>
              <tr>
      <td colspan="2"><?php echo $this->_tpl_vars['form']['address_name']['label']; ?>
<br />
        <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['address_name']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'medium') : smarty_modifier_crmAddClass($_tmp, 'medium')); ?>

      </td>
      <td><?php echo $this->_tpl_vars['form']['world_region']['label']; ?>
<br />
        <?php echo $this->_tpl_vars['form']['world_region']['html']; ?>
&nbsp;
      </td>
        </tr>
        <tr>
      <td colspan="2"><?php echo $this->_tpl_vars['form']['county']['label']; ?>
<br />
        <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['county']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'bigSelect') : smarty_modifier_crmAddClass($_tmp, 'bigSelect')); ?>
&nbsp;
      </td>
      <td><?php echo $this->_tpl_vars['form']['country']['label']; ?>
<br />
        <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['country']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'big') : smarty_modifier_crmAddClass($_tmp, 'big')); ?>
&nbsp;
      </td>
        </tr>
    </table>
        <?php endif; ?>&nbsp;
        </td>
        <td><?php echo $this->_tpl_vars['form']['state_province']['label']; ?>
<br />
            <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['state_province']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'bigSelect') : smarty_modifier_crmAddClass($_tmp, 'bigSelect')); ?>

        </td>
    </tr>
    <?php if ($this->_tpl_vars['addressGroupTree']): ?>
        <tr>
      <td colspan="2">
          <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Custom/Form/Search.tpl", 'smarty_include_vars' => array('groupTree' => $this->_tpl_vars['addressGroupTree'],'showHideLinks' => false)));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
            </td>
        </tr>
    <?php endif; ?>
    </table>
</div>

<?php if ($this->_tpl_vars['parseStreetAddress'] == 1): ?>
<?php echo '
<script type="text/javascript">
function processAddressFields( name, loadData ) {
    if ( name == \'addressElements\' ) {
        if ( loadData ) {
      cj( \'#street_address\' ).val( \'\' );
      }

      cj(\'#addressElements\').show();
      cj(\'#streetAddress\').hide();
  } else {
        if ( loadData ) {
             cj( \'#street_name\'   ).val( \'\' );
             cj( \'#street_unit\'   ).val( \'\' );
             cj( \'#street_number\' ).val( \'\' );
        }

        cj(\'#streetAddress\').show();
        cj(\'#addressElements\').hide();
       }

}

cj(function( ) {
  if (  cj(\'#street_name\').val( ).length > 0 ||
        cj(\'#street_unit\').val( ).length > 0 ||
        cj(\'#street_number\').val( ).length > 0 ) {
    processAddressFields( \'addressElements\', 1 );
  }
}
);

</script>
'; ?>

<?php endif; ?>


<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>