<?php /* Smarty version 2.6.27, created on 2014-06-21 02:53:27
         compiled from CRM/Contribute/Form/Contribution/OnBehalfOf.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 1, false),array('block', 'ts', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 64, false),array('modifier', 'crmAddClass', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 62, false),array('modifier', 'substr', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 115, false),array('modifier', 'replace', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 116, false),array('function', 'crmURL', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 151, false),array('function', 'crmSetting', 'CRM/Contribute/Form/Contribution/OnBehalfOf.tpl', 275, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>
<?php if ($this->_tpl_vars['buildOnBehalfForm'] || $this->_tpl_vars['onBehalfRequired']): ?>
<fieldset id="for_organization" class="for_organization-group">
<legend><?php echo $this->_tpl_vars['fieldSetTitle']; ?>
</legend>
  <?php if (( $this->_tpl_vars['relatedOrganizationFound'] || $this->_tpl_vars['onBehalfRequired'] ) && ! $this->_tpl_vars['organizationName']): ?>
    <div id='orgOptions' class="section crm-section">
      <div class="content">
        <?php echo $this->_tpl_vars['form']['org_option']['html']; ?>

      </div>
    </div>
  <?php endif; ?>

<div id="select_org" class="crm-section">
  <?php $_from = $this->_tpl_vars['onBehalfOfFields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['fieldName'] => $this->_tpl_vars['onBehaldField']):
?>
    <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['skipDisplay']): ?>
      <?php continue; ?>
    <?php endif; ?>
    <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['field_type'] == 'Formatting'): ?>
      <?php echo $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_pre']; ?>

      <?php continue; ?>
    <?php endif; ?>
    <div class="crm-section <?php echo $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['name']; ?>
-section">
      <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_pre']): ?>
        &nbsp;&nbsp;<span class='description'><?php echo $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_pre']; ?>
</span>
      <?php endif; ?>

      <?php if (( $this->_tpl_vars['fieldName'] == 'organization_name' ) && $this->_tpl_vars['organizationName']): ?>
        <div id='org_name' class="label"><?php echo $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']]['label']; ?>
</div>
        <div class="content">
          <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']]['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'big') : smarty_modifier_crmAddClass($_tmp, 'big')); ?>

          <span>
              ( <a id='createNewOrg' href="#" onclick="createNew( ); return false;"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Enter a new organization<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></a> )
          </span>
          <div id="id-onbehalf-orgname-enter-help" class="description">
            <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Organization details have been prefilled for you. If this is not the organization you want to use, click "Enter a new organization" above.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
          </div>
          <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_post']): ?>
            <span class='description'><?php echo $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_post']; ?>
</span>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['options_per_line']): ?>
          <div class="label option-label"><?php echo $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']]['label']; ?>
</div>
          <div class="content">
            <?php $this->assign('count', '1'); ?>
            <?php echo '<table class="form-layout-compressed"><tr>'; ?><?php echo ''; ?><?php $this->assign('index', '1'); ?><?php echo ''; ?><?php $_from = $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['outer'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['outer']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['item']):
        $this->_foreach['outer']['iteration']++;
?><?php echo ''; ?><?php if ($this->_tpl_vars['index'] < 10): ?><?php echo ''; ?><?php $this->assign('index', ($this->_tpl_vars['index']+1)); ?><?php echo ''; ?><?php else: ?><?php echo '<td class="labels font-light">'; ?><?php echo $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']][$this->_tpl_vars['key']]['html']; ?><?php echo '</td>'; ?><?php if ($this->_tpl_vars['count'] == $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['options_per_line']): ?><?php echo '</tr><tr>'; ?><?php $this->assign('count', '1'); ?><?php echo ''; ?><?php else: ?><?php echo ''; ?><?php $this->assign('count', ($this->_tpl_vars['count']+1)); ?><?php echo ''; ?><?php endif; ?><?php echo ''; ?><?php endif; ?><?php echo ''; ?><?php endforeach; endif; unset($_from); ?><?php echo '</tr></table>'; ?>

            <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_post']): ?>
              <span class='description'><?php echo $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_post']; ?>
</span>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <div class="label"><?php echo $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']]['label']; ?>
</div>
          <div class="content">
            <?php echo $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['fieldName']]['html']; ?>

            <?php if ($this->_tpl_vars['fieldName'] == 'organization_name'): ?>
              <div id="id-onbehalf-orgname-help" class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Start typing the name of an organization that you have saved previously to use it again. Otherwise click "Enter a new organization" above.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></div>
            <?php endif; ?>
            <?php if (! empty ( $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['html_type'] ) && $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['html_type'] == 'Autocomplete-Select'): ?>
              <?php $this->assign('elementName', "onbehalf[".($this->_tpl_vars['fieldName'])."]"); ?>
            <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Custom/Form/AutoComplete.tpl", 'smarty_include_vars' => array('element_name' => $this->_tpl_vars['elementName'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
            <?php endif; ?>
            <?php if (((is_array($_tmp=$this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['name'])) ? $this->_run_mod_handler('substr', true, $_tmp, 0, 5) : substr($_tmp, 0, 5)) == 'phone'): ?>
              <?php $this->assign('phone_ext_field', ((is_array($_tmp=$this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['name'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'phone', 'phone_ext') : smarty_modifier_replace($_tmp, 'phone', 'phone_ext'))); ?>
              <?php if ($this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['phone_ext_field']]['html']): ?>
                &nbsp;<?php echo $this->_tpl_vars['form']['onbehalf'][$this->_tpl_vars['phone_ext_field']]['html']; ?>

              <?php endif; ?>
            <?php endif; ?>
            <?php if ($this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_post']): ?>
              <br /><span class='description'><?php echo $this->_tpl_vars['onBehalfOfFields'][$this->_tpl_vars['fieldName']]['help_post']; ?>
</span>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
      <div class="clear"></div>
    </div>
  <?php endforeach; endif; unset($_from); ?>
</div>
<div><?php echo $this->_tpl_vars['form']['mode']['html']; ?>
</div>
</fieldset>
<?php endif; ?>
<?php if (empty ( $this->_tpl_vars['snippet'] )): ?>
<?php echo '
<script type="text/javascript">
  cj( "div#id-onbehalf-orgname-help").hide( );

  showOnBehalf('; ?>
"<?php echo $this->_tpl_vars['onBehalfRequired']; ?>
"<?php echo ');

  cj( "#mode" ).hide( );
  cj( "#mode" ).attr( \'checked\', \'checked\' );
  if ( cj( "#mode" ).attr( \'checked\' ) && !'; ?>
"<?php echo $this->_tpl_vars['reset']; ?>
"<?php echo ' ) {
    $text = \' '; ?>
<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use existing organization<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo ' \';
    cj( "#createNewOrg" ).text( $text );
    cj( "#mode" ).removeAttr( \'checked\' );
  }

function showOnBehalf(onBehalfRequired) {
  if ( cj( "#is_for_organization" ).attr( \'checked\' ) || onBehalfRequired ) {
    var urlPath = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => $this->_tpl_vars['urlPath'],'h' => 0,'q' => "snippet=4&onbehalf=1&id=".($this->_tpl_vars['contributionPageID'])."&qfKey=".($this->_tpl_vars['qfKey'])), $this);?>
";
    <?php if ($this->_tpl_vars['mode'] == 'test'): ?>
      urlPath += '&action=preview';
    <?php endif; ?>
    <?php if ($this->_tpl_vars['reset']): ?>
      urlPath += '&reset=<?php echo $this->_tpl_vars['reset']; ?>
';
    <?php endif; ?><?php echo '
    cj("#onBehalfOfOrg").show();
    if (cj("fieldset", \'#onBehalfOfOrg\').length < 1) {
      cj(\'#onBehalfOfOrg\').load(urlPath);
    }
  }
  else {
    cj("#onBehalfOfOrg").hide();
  }
}

function resetValues( filter ) {
  if (filter) {
    cj("#select_org div").find( \'input[type=text], select, textarea\' ).each(function( ) {
      if ( cj(this).attr(\'name\') != \'onbehalf[organization_name]\' ) {
        cj(this).val(\'\');
      }
    });
  }
  else {
    cj("#select_org div").find( \'input[type=text], select, textarea\' ).each(function( ) {
      cj(this).val( \'\' );
    });
  }
  cj("#select_org tr td").find( \'input[type=radio], input[type=checkbox]\' ).each(function( ) {
    cj(this).attr(\'checked\', false);
  });
}

function createNew( ) {
  if (cj("#mode").attr(\'checked\')) {
    var textMessage = \' '; ?>
<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use existing organization<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo ' \';
    cj("#onbehalf_organization_name").removeAttr(\'readonly\');
    cj("#mode").removeAttr(\'checked\');
    resetValues( false );
  }
  else {
    var textMessage = \' '; ?>
<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Enter a new organization<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo ' \';
    cj("#mode").attr(\'checked\', \'checked\');
    setOrgName( );
  }
  cj("#createNewOrg").text(textMessage);
}

function setOrgName( ) {
  var orgName = "'; ?>
<?php echo $this->_tpl_vars['organizationName']; ?>
<?php echo '";
  var orgId   = "'; ?>
<?php echo $this->_tpl_vars['orgId']; ?>
<?php echo '";
  cj("#onbehalf_organization_name").val(orgName);
  cj("#onbehalf_organization_name").attr(\'readonly\', true);
  setLocationDetails(orgId);
}


function setLocationDetails(contactID) {
  resetValues(true);
  var locationUrl = '; ?>
"<?php echo $this->_tpl_vars['locDataURL']; ?>
"<?php echo ' + contactID + "&ufId=" + '; ?>
"<?php echo $this->_tpl_vars['profileId']; ?>
"<?php echo ';
  cj.ajax({
    url         : locationUrl,
    dataType    : "json",
    timeout     : 5000, //Time in milliseconds
    success     : function(data, status) {
      for (var ele in data) {
        if (data[ele].type == \'Radio\') {
          if (data[ele].value) {
            cj("input[name=\'"+ ele +"\']").filter("[value=" + data[ele].value + "]").attr(\'checked\', \'checked\');
          }
        }
        else if (data[ele].type == \'CheckBox\') {
          if (data[ele].value) {
            cj("input[name=\'"+ ele +"\']").attr(\'checked\',\'checked\');
          }
        }
        else if (data[ele].type == \'Multi-Select\') {
          for (var selectedOption in data[ele].value) {
            cj(\'#\' + ele + " option[value=\'" + selectedOption + "\']").attr(\'selected\', \'selected\');
          }
        }
        else if (data[ele].type == \'Autocomplete-Select\') {
          cj(\'#\' + ele ).val( data[ele].value );
          cj(\'#\' + ele + \'_id\').val(data[ele].id);
        }
        else if (data[ele].type == \'AdvMulti-Select\') {
          var customFld = ele.replace(\'onbehalf_\', \'\');
          // remove empty value if any
          cj(\'#onbehalf\\\\[\'+ customFld +\'\\\\]-f option[value=""]\').remove();
          cj(\'#onbehalf\\\\[\'+ customFld +\'\\\\]-t option[value=""]\').remove();

          for (var selectedOption in data[ele].value) {
            // remove selected values from left and selected values to right
            cj(\'#onbehalf\\\\[\'+ customFld +\'\\\\]-f option[value="\' + selectedOption + \'"]\').remove()
              .appendTo(\'#onbehalf\\\\[\'+ customFld +\'\\\\]-t\');
          }
        }
        else {
          cj(\'#\' + ele ).val(data[ele].value);
        }
      }
    },
    error       : function(XMLHttpRequest, textStatus, errorThrown) {
      console.error("HTTP error status: ", textStatus);
    }
  });
}

var orgOption = \'\';
cj("input:radio[name=\'org_option\']").click( function( ) {
  orgOption = cj("input:radio[name=\'org_option\']:checked").val( );
  selectCreateOrg(orgOption, true);
});

function selectCreateOrg( orgOption, reset ) {
  if (orgOption == 0) {
    cj("div#id-onbehalf-orgname-help").show( );
    var dataUrl = '; ?>
"<?php echo $this->_tpl_vars['employerDataURL']; ?>
"<?php echo ';
    cj(\'#onbehalf_organization_name\').autocomplete( dataUrl,
      { width         : 180,
        selectFirst   : false,
        matchContains : true,
        max: '; ?>
<?php echo smarty_function_crmSetting(array('name' => 'search_autocomplete_count','group' => 'Search Preferences'), $this);?>
<?php echo '
      }).result( function( event, data, formatted ) {
        cj(\'#onbehalf_organization_name\').val( data[0] );
        cj(\'#onbehalfof_id\').val( data[1] );
        setLocationDetails( data[1] );
      });
  }
  else if ( orgOption == 1 ) {
    cj("input#onbehalf_organization_name").removeClass( \'ac_input\' ).unautocomplete( );
    cj("div#id-onbehalf-orgname-help").hide( );
  }

  if ( reset ) {
    resetValues( false );
  }
}

'; ?>

<?php if (( $this->_tpl_vars['relatedOrganizationFound'] || $this->_tpl_vars['onBehalfRequired'] ) && $this->_tpl_vars['reset'] && $this->_tpl_vars['organizationName']): ?>
  setOrgName( );
<?php else: ?>
  cj("#orgOptions").show( );
  var orgOption = cj("input:radio[name=org_option]:checked").val( );
  selectCreateOrg(orgOption, false);
<?php endif; ?>

<?php if ($this->_tpl_vars['membershipContactID']): ?>
<?php echo '
  cj( function( ) {
    cj(\'#organization_id\').val("'; ?>
<?php echo $this->_tpl_vars['membershipContactName']; ?>
<?php echo '");
    cj(\'#organization_name\').val("'; ?>
<?php echo $this->_tpl_vars['membershipContactName']; ?>
<?php echo '");
    cj(\'#onbehalfof_id\').val("'; ?>
<?php echo $this->_tpl_vars['membershipContactID']; ?>
<?php echo '");
    setLocationDetails( "'; ?>
<?php echo $this->_tpl_vars['membershipContactID']; ?>
<?php echo '" );
  });
'; ?>

<?php endif; ?>

</script>
<?php endif; ?>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>