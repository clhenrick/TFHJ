<?php /* Smarty version 2.6.27, created on 2014-07-07 10:37:06
         compiled from CRM/Volunteer/Form/Volunteer.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Volunteer/Form/Volunteer.tpl', 1, false),array('block', 'ts', 'CRM/Volunteer/Form/Volunteer.tpl', 37, false),array('function', 'crmURL', 'CRM/Volunteer/Form/Volunteer.tpl', 27, false),array('function', 'help', 'CRM/Volunteer/Form/Volunteer.tpl', 40, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>
<?php ob_start(); ?><?php echo CRM_Utils_System::crmURL(array('p' => "civicrm/volunteer/loghours",'q' => "reset=1&action=add&vid=".($this->_tpl_vars['vid'])), $this);?>
<?php $this->_smarty_vars['capture']['default'] = ob_get_contents();  $this->assign('volunteerLogURL', ob_get_contents());ob_end_clean(); ?>

<div id="help">
  <?php if ($this->_tpl_vars['form']['is_active']['value']): ?>
    <p>
      Volunteer Management is enabled for this event. Note that only users with
      the "register to volunteer" permission will be able to access the
      volunteer sign-up form. Click one of the buttons below to get started.
    </p>
    <p>
      <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>If you want to disable Volunteer Management for this event, uncheck
      the box below and submit the form. Disabling Volunteer Management for this
      event will not result in loss of volunteer data.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
      <?php echo smarty_function_help(array('id' => "id-volunteer-init"), $this);?>

    </p>
  <?php else: ?>
    <p>
      <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>If you want to enable Volunteer Management for this event, check
      the box below and submit the form.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
      <?php echo smarty_function_help(array('id' => "id-volunteer-init"), $this);?>

    </p>
  <?php endif; ?>
</div>

<?php if ($this->_tpl_vars['form']['is_active']['value']): ?>
<table class="crm-block crm-form-block crm-event-manage-volunteer-form-block">
  <tr>
    <td><a href="#" class="button crm-volunteer-popup" data-vid="<?php echo $this->_tpl_vars['vid']; ?>
" data-tab="Define"><span><div class="icon edit-icon"></div><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Define Volunteer Needs<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a></td>
    <td><a href="#" class="button crm-volunteer-popup" data-vid="<?php echo $this->_tpl_vars['vid']; ?>
" data-tab="Assign"><span><div class="icon edit-icon"></div><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Assign Volunteers<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a></td>
    <td><a href="<?php echo $this->_tpl_vars['volunteerLogURL']; ?>
" class="button crm-volunteer-faux-popup"><span><div class="icon edit-icon"></div><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Log Volunteer Hours<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a></td>
  </tr>
</table>
<?php endif; ?>

<div class="crm-block crm-form-block crm-event-manage-volunteer-form-block">
  <table class="form-layout">
    <tr class="crm-event-manage-volunteer-form-block-is_active">
      <td class="label"><?php echo $this->_tpl_vars['form']['is_active']['label']; ?>
</td>
      <td><?php echo $this->_tpl_vars['form']['is_active']['html']; ?>

        <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Enable or disable volunteer management for this event.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
      </td>
    </tr>
  </table>
  <div id="org_civicrm_volunteer-event_tab_config">
    <table class="form-layout">
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Contact/Form/NewContact.tpl", 'smarty_include_vars' => array('blockNo' => 1,'prefix' => 'volunteer_target_')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    </table>
    <div class="org_civicrm_volunteer-beneficiary_help">
      <?php echo smarty_function_help(array('id' => "id-volunteer-beneficiary"), $this);?>

    </div>
  </div>
  <div class="crm-submit-buttons">
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'bottom')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
  </div>
</div>

<script type="text/javascript">
  <?php echo '
    cj(function($) {
      $(document).on(\'change\', \'#is_active\', function(){
        if ($(this).is(\':checked\')) {
          $(\'#org_civicrm_volunteer-event_tab_config\').show();
        } else {
          $(\'#org_civicrm_volunteer-event_tab_config\').hide();
        }
      });

      $(\'#is_active\').trigger(\'change\');
    });
  '; ?>

</script><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>