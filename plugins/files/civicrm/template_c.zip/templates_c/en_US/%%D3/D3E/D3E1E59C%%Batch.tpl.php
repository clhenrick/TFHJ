<?php /* Smarty version 2.6.27, created on 2014-08-01 17:58:35
         compiled from CRM/Contribute/Form/Task/Batch.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Contribute/Form/Task/Batch.tpl', 1, false),array('block', 'ts', 'CRM/Contribute/Form/Task/Batch.tpl', 29, false),array('function', 'cycle', 'CRM/Contribute/Form/Task/Batch.tpl', 45, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><div class="batch-update form-item">
<fieldset>
<div id="help">
    <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Update field values for each contribution as needed. Click <strong>Update Contributions</strong> below to save all your changes. To set a field to the same value for ALL rows, enter that value for the first contribution and then click the <strong>Copy icon</strong> (next to the column title).<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
</div>
    <legend><?php echo $this->_tpl_vars['profileTitle']; ?>
</legend>
    <table class="crm-copy-fields">
    <thead class="sticky">
            <tr class="columnheader">
             <?php $_from = $this->_tpl_vars['readOnlyFields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['fName'] => $this->_tpl_vars['fTitle']):
?>
              <th><?php echo $this->_tpl_vars['fTitle']; ?>
</th>
            <?php endforeach; endif; unset($_from); ?>

             <?php $_from = $this->_tpl_vars['fields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['fieldName'] => $this->_tpl_vars['field']):
?>
                <td><img  src="<?php echo $this->_tpl_vars['config']->resourceBase; ?>
i/copy.png" alt="<?php $this->_tag_stack[] = array('ts', array('1' => $this->_tpl_vars['field']['title'])); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Click to copy %1 from row one to all rows.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>" fname="<?php echo $this->_tpl_vars['field']['name']; ?>
" class="action-icon" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Click here to copy the value in row one to ALL rows.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>" /><?php echo $this->_tpl_vars['field']['title']; ?>
</td>
             <?php endforeach; endif; unset($_from); ?>
            </tr>
          </thead>
            <?php $_from = $this->_tpl_vars['componentIds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['cid']):
?>
             <tr class="<?php echo smarty_function_cycle(array('values' => "odd-row,even-row"), $this);?>
" entity_id="<?php echo $this->_tpl_vars['cid']; ?>
">
        <?php $_from = $this->_tpl_vars['readOnlyFields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['fName'] => $this->_tpl_vars['fTitle']):
?>
           <td><?php echo $this->_tpl_vars['contactDetails'][$this->_tpl_vars['cid']][$this->_tpl_vars['fName']]; ?>
</td>
        <?php endforeach; endif; unset($_from); ?>

              <?php $_from = $this->_tpl_vars['fields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['fieldName'] => $this->_tpl_vars['field']):
?>
                <?php $this->assign('n', $this->_tpl_vars['field']['name']); ?>
                <?php if (( $this->_tpl_vars['fields'][$this->_tpl_vars['n']]['data_type'] == 'Date' ) || ( $this->_tpl_vars['n'] == 'thankyou_date' ) || ( $this->_tpl_vars['n'] == 'cancel_date' ) || ( $this->_tpl_vars['n'] == 'receipt_date' ) || ( $this->_tpl_vars['n'] == 'receive_date' )): ?>
                   <td class="compressed"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/jcalendar.tpl", 'smarty_include_vars' => array('elementName' => $this->_tpl_vars['n'],'elementIndex' => $this->_tpl_vars['cid'],'batchUpdate' => 1)));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></td>
                <?php else: ?>
                   <td class="compressed"><?php echo $this->_tpl_vars['form']['field'][$this->_tpl_vars['cid']][$this->_tpl_vars['n']]['html']; ?>
</td>
                <?php endif; ?>
              <?php endforeach; endif; unset($_from); ?>
             </tr>
            <?php endforeach; endif; unset($_from); ?>
           </tr>
         </table>
         <div class="crm-submit-buttons"><?php if ($this->_tpl_vars['fields']): ?><?php echo $this->_tpl_vars['form']['_qf_Batch_refresh']['html']; ?>
<?php endif; ?> &nbsp; <?php echo $this->_tpl_vars['form']['buttons']['html']; ?>
</div>
        </fieldset>
</div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/batchCopy.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>