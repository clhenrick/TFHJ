<?php /* Smarty version 2.6.27, created on 2014-06-19 13:52:54
         compiled from CRM/common/paymentBlock.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/common/paymentBlock.tpl', 1, false),array('function', 'crmURL', 'CRM/common/paymentBlock.tpl', 37, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo '
<script type="text/javascript">

function buildPaymentBlock( type ) {
    if ( type == 0 ) {
     if (cj("#billing-payment-block").length) {
           cj("#billing-payment-block").html(\'\');
   }
        return;
    }

  var dataUrl = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => $this->_tpl_vars['urlPath'],'h' => 0,'q' => 'snippet=4&type='), $this);?>
"<?php echo ' + type;

  '; ?>

    <?php if ($this->_tpl_vars['urlPathVar']): ?>
      dataUrl = dataUrl + '&' + '<?php echo $this->_tpl_vars['urlPathVar']; ?>
'
    <?php endif; ?>

    <?php if ($this->_tpl_vars['contributionPageID']): ?>
            dataUrl = dataUrl + '&id=' + '<?php echo $this->_tpl_vars['contributionPageID']; ?>
'
        <?php endif; ?>

    <?php if ($this->_tpl_vars['qfKey']): ?>
      dataUrl = dataUrl + '&qfKey=' + '<?php echo $this->_tpl_vars['qfKey']; ?>
'
    <?php endif; ?>
  <?php echo '

  var response = cj.ajax({
                        url: dataUrl,
                        async: false
                        }).responseText;

  cj(\'#billing-payment-block\').html(response).trigger(\'crmFormLoad\');
}

cj( function() {
    cj(\'.crm-group.payment_options-group\').show();

    cj(\'input[name="payment_processor"]\').change( function() {
        buildPaymentBlock( cj(this).val() );
    });
});

</script>
'; ?>

<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>