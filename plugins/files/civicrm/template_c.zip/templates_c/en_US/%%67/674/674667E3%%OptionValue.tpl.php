<?php /* Smarty version 2.6.27, created on 2014-07-30 14:56:19
         compiled from CRM/Admin/Form/OptionValue.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Admin/Form/OptionValue.tpl', 1, false),array('block', 'ts', 'CRM/Admin/Form/OptionValue.tpl', 27, false),array('modifier', 'count', 'CRM/Admin/Form/OptionValue.tpl', 48, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><h3><?php if ($this->_tpl_vars['action'] == 1): ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>New Option Value<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php elseif ($this->_tpl_vars['action'] == 2): ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Edit Option Value<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php else: ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Delete Option Value<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php endif; ?></h3>
<div class="crm-block crm-form-block crm-admin-optionvalue-form-block">
   <?php if ($this->_tpl_vars['action'] == 8): ?>
      <div class="messages status no-popup">
          <div class="icon inform-icon"></div>
          <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>WARNING: Deleting this option value will result in the loss of all records which use the option value.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>This may mean the loss of a substantial amount of data, and the action cannot be undone.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Do you want to continue?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
      </div>
   <?php else: ?>
      <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'top')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
      <table class="form-layout-compressed">
        <tr class="crm-admin-optionvalue-form-block-label">
            <td class="label"><?php echo $this->_tpl_vars['form']['label']['label']; ?>

              <?php if ($this->_tpl_vars['action'] == 2): ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'CRM/Core/I18n/Dialog.tpl', 'smarty_include_vars' => array('table' => 'civicrm_option_value','field' => 'label','id' => $this->_tpl_vars['id'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php endif; ?></td>
            <td><?php echo $this->_tpl_vars['form']['label']['html']; ?>
</td>
        </tr>
        <tr class="crm-admin-optionvalue-form-block-value">
            <td class="label"><?php echo $this->_tpl_vars['form']['value']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['value']['html']; ?>
<br />
            <?php if ($this->_tpl_vars['action'] == 2): ?>
              <span class="description red"><div class="icon alert-icon"></div><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Changing the Value field will unlink records which have been marked with this option. This change can not be undone except by restoring the previous value.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
            <?php endif; ?>
            <?php if (count($this->_tpl_vars['config']->languageLimit) >= 2): ?><br />
              <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>The same option value is stored for all languages. Changing this value will change it for all languages.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span>
            <?php endif; ?>
            </td>
        </tr>
        <tr class="crm-admin-optionvalue-form-block-name">
            <td class="label"><?php echo $this->_tpl_vars['form']['name']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['name']['html']; ?>
</td>
        </tr>
        <tr class="crm-admin-optionvalue-form-block-grouping">
            <td class="label"><?php echo $this->_tpl_vars['form']['grouping']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['grouping']['html']; ?>
</td>
        </tr>
  <?php if ($this->_tpl_vars['form']['financial_account_id']): ?>
          <tr class="crm-admin-optionvalue-form-block-financialAccount">
            <td class="label"><?php echo $this->_tpl_vars['form']['financial_account_id']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['financial_account_id']['html']; ?>
</td>
          </tr>
  <?php endif; ?>
        <tr class="crm-admin-optionvalue-form-block-description">
            <td class="label"><?php echo $this->_tpl_vars['form']['description']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['description']['html']; ?>
</td>
        </tr>
        <tr class="crm-admin-optionvalue-form-block-weight">
            <td class="label"><?php echo $this->_tpl_vars['form']['weight']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['weight']['html']; ?>
</td>
        </tr>
        <?php if ($this->_tpl_vars['form']['is_default']): ?>
        <tr class="crm-admin-optionvalue-form-block-is_default">
            <td class="label"><?php echo $this->_tpl_vars['form']['is_default']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['is_default']['html']; ?>
</td>
        </tr>
        <?php endif; ?>
        <tr class="crm-admin-optionvalue-form-block-is_active">
            <td class="label"><?php echo $this->_tpl_vars['form']['is_active']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['is_active']['html']; ?>
</td>
        </tr>
        <tr class="crm-admin-optionvalue-form-block-is_optgroup">
            <td class="label"><?php echo $this->_tpl_vars['form']['is_optgroup']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['is_optgroup']['html']; ?>
</td>
        </tr>
       <?php if ($this->_tpl_vars['form']['contactOptions']): ?>        <tr class="crm-admin-optionvalue-form-block-contactOptions">
            <td class="label"><?php echo $this->_tpl_vars['form']['contactOptions']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['contactOptions']['html']; ?>
</td>
        </tr>
       <?php endif; ?>
      </table>
     <?php endif; ?>
     <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'bottom')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
</div>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>