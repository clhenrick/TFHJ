<?php /* Smarty version 2.6.27, created on 2014-07-01 16:59:16
         compiled from CRM/Event/Form/Participant.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Event/Form/Participant.tpl', 1, false),array('block', 'ts', 'CRM/Event/Form/Participant.tpl', 123, false),array('function', 'crmURL', 'CRM/Event/Form/Participant.tpl', 205, false),array('modifier', 'crmDate', 'CRM/Event/Form/Participant.tpl', 242, false),array('modifier', 'crmAddClass', 'CRM/Event/Form/Participant.tpl', 253, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php if ($this->_tpl_vars['showFeeBlock']): ?>
  <?php if ($this->_tpl_vars['priceSet']): ?>
  <div id='validate_pricefield' class='messages crm-error hiddenElement'></div>
    <?php echo '
    <script type="text/javascript">

    var fieldOptionsFull = new Array( );
    '; ?>

    <?php $_from = $this->_tpl_vars['priceSet']['fields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['fldId'] => $this->_tpl_vars['fldElement']):
?>
      <?php if ($this->_tpl_vars['fldElement']['options']): ?>
        <?php $_from = $this->_tpl_vars['fldElement']['options']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['opId'] => $this->_tpl_vars['fldOptions']):
?>
          <?php if ($this->_tpl_vars['fldOptions']['is_full']): ?>
            <?php echo '
              fieldOptionsFull['; ?>
<?php echo $this->_tpl_vars['fldId']; ?>
<?php echo '] = new Array( );
            fieldOptionsFull['; ?>
<?php echo $this->_tpl_vars['fldId']; ?>
<?php echo ']['; ?>
<?php echo $this->_tpl_vars['opId']; ?>
<?php echo '] = 1;
          '; ?>

          <?php endif; ?>
        <?php endforeach; endif; unset($_from); ?>
      <?php endif; ?>
    <?php endforeach; endif; unset($_from); ?>
    <?php echo '

    if ( fieldOptionsFull.length > 0 ) {
      cj(function() {
        cj("input,#priceset select,#priceset").each(function () {
          if ( cj(this).attr(\'price\') ) {
            switch( cj(this).attr(\'type\') ) {
              case \'checkbox\':
              case \'radio\':
                cj(this).click( function() {
                  validatePriceField(this);
                });
                break;

              case \'select-one\':
                cj(this).change( function() {
                  validatePriceField(this);
                });
                break;
              case \'text\':
                cj(this).bind( \'keyup\', function() { validatePriceField(this) });
                break;
            }
          }
        });
      });

      function validatePriceField( obj ) {
        var namePart =  cj(obj).attr(\'name\').split(\'_\');
        var fldVal  =  cj(obj).val();
        if ( cj(obj).attr(\'type\') == \'checkbox\') {
          var eleIdpart = namePart[1].split(\'[\');
          var eleId = eleIdpart[0];
        }
        else {
          var eleId  = namePart[1];
        }
        var showError = false;

        switch( cj(obj).attr(\'type\') ) {
          case \'text\':
            if ( fieldOptionsFull[eleId] && fldVal ) {
              showError = true;
              cj(obj).parent( ).parent( ).children(\'.label\').addClass(\'crm-error\');
            }
            else {
              cj(obj).parent( ).parent( ).children(\'.label\').removeClass(\'crm-error\');
              cj(\'#validate_pricefield\').hide( ).html(\'\');
            }
            break;

          case \'checkbox\':
            var checkBoxValue = eleIdpart[1].split(\']\');
            if ( cj(obj).attr("checked") == true &&
              fieldOptionsFull[eleId] &&
              fieldOptionsFull[eleId][checkBoxValue[0]]) {
              showError = true;
              cj(obj).parent( ).addClass(\'crm-error\');
            }
            else {
              cj(obj).parent( ).removeClass(\'crm-error\');
            }
            break;

          default:
            if ( fieldOptionsFull[eleId] &&
              fieldOptionsFull[eleId][fldVal]  ) {
              showError = true;
              cj(obj).parent( ).addClass(\'crm-error\');
            }
            else {
              cj(obj).parent( ).removeClass(\'crm-error\');
            }
          }

        if ( showError ) {
          cj(\'#validate_pricefield\').show().html("<span class=\'icon red-icon alert-icon\'></span>'; ?>
<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>This Option is already full for this event.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '");
        }
        else {
          cj(\'#validate_pricefield\').hide( ).html(\'\');
        }
      }
    }
  </script>
  '; ?>

  <?php endif; ?>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Event/Form/EventFees.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php elseif ($this->_tpl_vars['cdType']): ?>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Custom/Form/CustomData.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php else: ?>
  <?php if ($this->_tpl_vars['participantMode'] == 'test'): ?>
    <?php $this->assign('registerMode', 'TEST'); ?>
    <?php elseif ($this->_tpl_vars['participantMode'] == 'live'): ?>
    <?php $this->assign('registerMode', 'LIVE'); ?>
  <?php endif; ?>
  <h3><?php if ($this->_tpl_vars['action'] == 1): ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>New Event Registration<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php elseif ($this->_tpl_vars['action'] == 8): ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Delete Event Registration<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php else: ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Edit Event Registration<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php endif; ?></h3>
  <div class="crm-block crm-form-block crm-participant-form-block">
    <div class="view-content">
      <?php if ($this->_tpl_vars['participantMode']): ?>
        <div id="help">
          <?php $this->_tag_stack[] = array('ts', array('1' => $this->_tpl_vars['displayName'],'2' => $this->_tpl_vars['registerMode'])); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Use this form to submit an event registration on behalf of %1. <strong>A %2 transaction will be submitted</strong> using the selected payment processor.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
        </div>
      <?php endif; ?>
      <div id="eventFullMsg" class="messages status no-popup" style="display:none;"></div>


      <?php if ($this->_tpl_vars['action'] == 1 && $this->_tpl_vars['paid']): ?>
        <div id="help">
          <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>If you are accepting offline payment from this participant, check <strong>Record Payment</strong>. You will be able to fill in the payment information, and optionally send a receipt.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
        </div>
      <?php endif; ?>

      <?php if ($this->_tpl_vars['action'] == 8): ?>         <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'top')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
        <div class="crm-participant-form-block-delete messages status no-popup">
          <div class="crm-content">
            <div class="icon inform-icon"></div> &nbsp;
            <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>WARNING: Deleting this registration will result in the loss of related payment records (if any).<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Do you want to continue?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
          </div>
          <?php if ($this->_tpl_vars['additionalParticipant']): ?>
            <div class="crm-content">
              <?php $this->_tag_stack[] = array('ts', array('1' => $this->_tpl_vars['additionalParticipant'])); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?> There are %1 more Participant(s) registered by this participant.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
            </div>
          <?php endif; ?>
        </div>
        <?php if ($this->_tpl_vars['additionalParticipant']): ?>
          <?php echo $this->_tpl_vars['form']['delete_participant']['html']; ?>

        <?php endif; ?>
        <?php else: ?>         <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'top')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
        <table class="form-layout-compressed">
          <?php if ($this->_tpl_vars['single'] && $this->_tpl_vars['context'] != 'standalone'): ?>
            <tr class="crm-participant-form-block-displayName">
              <td class="label font-size12pt"><label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label></td>
              <td class="font-size12pt view-value"><?php echo $this->_tpl_vars['displayName']; ?>
&nbsp;</td>
            </tr>
            <?php else: ?>
            <?php if (! $this->_tpl_vars['participantMode'] && ! $this->_tpl_vars['email'] && $this->_tpl_vars['outBound_option'] != 2): ?>
              <?php $this->assign('profileCreateCallback', 1); ?>
            <?php endif; ?>
          <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Contact/Form/NewContact.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          <?php endif; ?>
          <?php if ($this->_tpl_vars['action'] == 2): ?>
            <?php if ($this->_tpl_vars['additionalParticipants']): ?>               <tr class="crm-participant-form-block-additionalParticipants">
                <td class="label"><label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Also Registered by this Participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label></td>
                <td>
                  <?php $_from = $this->_tpl_vars['additionalParticipants']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['apName'] => $this->_tpl_vars['apURL']):
?>
                    <a href="<?php echo $this->_tpl_vars['apURL']; ?>
" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>view additional participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"><?php echo $this->_tpl_vars['apName']; ?>
</a><br />
                  <?php endforeach; endif; unset($_from); ?>
                </td>
              </tr>
            <?php endif; ?>
            <?php if ($this->_tpl_vars['registered_by_contact_id']): ?>
              <tr class="crm-participant-form-block-registered-by">
                <td class="label"><label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Registered By<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label></td>
                <td class="view-value">
                  <a href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view/participant','q' => "reset=1&id=".($this->_tpl_vars['participant_registered_by_id'])."&cid=".($this->_tpl_vars['registered_by_contact_id'])."&action=view"), $this);?>
"
                     title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>view primary participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"><?php echo $this->_tpl_vars['registered_by_display_name']; ?>
</a>
                </td>
              </tr>
            <?php endif; ?>
          <?php endif; ?>
          <?php if ($this->_tpl_vars['participantMode']): ?>
            <tr class="crm-participant-form-block-payment_processor_id">
              <td class="label nowrap"><?php echo $this->_tpl_vars['form']['payment_processor_id']['label']; ?>
</td>
              <td><?php echo $this->_tpl_vars['form']['payment_processor_id']['html']; ?>
</td>
            </tr>
          <?php endif; ?>
          <tr class="crm-participant-form-block-event_id">
            <td class="label"><?php echo $this->_tpl_vars['form']['event_id']['label']; ?>
</td><td class="view-value bold"><?php echo $this->_tpl_vars['form']['event_id']['html']; ?>
&nbsp;
            <?php if ($this->_tpl_vars['action'] == 1): ?><span id='past-event-section'>
              <br />&raquo; <span id="showing-event-info"></span>
            <?php endif; ?>
            <?php if ($this->_tpl_vars['is_test']): ?>
              <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>(test)<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
            <?php endif; ?>
          </td>
          </tr>

                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Campaign/Form/addCampaignToComponent.tpl", 'smarty_include_vars' => array('campaignTrClass' => "crm-participant-form-block-campaign_id")));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

          <tr class="crm-participant-form-block-role_id">
            <td class="label"><?php echo $this->_tpl_vars['form']['role_id']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['role_id']['html']; ?>
</td>
          </tr>
          <tr class="crm-participant-form-block-register_date">
            <td class="label"><?php echo $this->_tpl_vars['form']['register_date']['label']; ?>
</td>
            <td>
              <?php if ($this->_tpl_vars['hideCalendar'] != true): ?>
                    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/jcalendar.tpl", 'smarty_include_vars' => array('elementName' => 'register_date')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                  <?php else: ?>
                    <?php echo ((is_array($_tmp=$this->_tpl_vars['form']['register_date']['html'])) ? $this->_run_mod_handler('crmDate', true, $_tmp) : smarty_modifier_crmDate($_tmp)); ?>

                  <?php endif; ?>
            </td>
          </tr>
          <tr class="crm-participant-form-block-status_id">
            <td class="label"><?php echo $this->_tpl_vars['form']['status_id']['label']; ?>
</td>
            <td><?php echo $this->_tpl_vars['form']['status_id']['html']; ?>
<?php if ($this->_tpl_vars['event_is_test']): ?> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>(test)<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php endif; ?>
              <div id="notify"><?php echo $this->_tpl_vars['form']['is_notify']['html']; ?>
<?php echo $this->_tpl_vars['form']['is_notify']['label']; ?>
</div>
            </td>
          </tr>
          <tr class="crm-participant-form-block-source">
            <td class="label"><?php echo $this->_tpl_vars['form']['source']['label']; ?>
</td><td><?php echo ((is_array($_tmp=$this->_tpl_vars['form']['source']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'huge') : smarty_modifier_crmAddClass($_tmp, 'huge')); ?>
<br />
            <span class="description"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Source for this registration (if applicable).<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></td>
          </tr>
        </table>

              <div id="feeBlock"></div>
        <fieldset>
          <table class="form-layout">
            <tr class="crm-participant-form-block-note">
              <td class="label"><?php echo $this->_tpl_vars['form']['note']['label']; ?>
</td><td><?php echo $this->_tpl_vars['form']['note']['html']; ?>
</td>
            </tr>
          </table>
        </fieldset>

        <div class="crm-participant-form-block-customData">
          <div id="customData" class="crm-customData-block"></div>            <div id="customData<?php echo $this->_tpl_vars['eventNameCustomDataTypeID']; ?>
" class="crm-customData-block"></div>           <div id="customData<?php echo $this->_tpl_vars['roleCustomDataTypeID']; ?>
" class="crm-customData-block"></div>           <div id="customData<?php echo $this->_tpl_vars['eventTypeCustomDataTypeID']; ?>
" class="crm-customData-block"></div>         </div>
      <?php endif; ?>

      <?php if ($this->_tpl_vars['accessContribution'] && $this->_tpl_vars['action'] == 2 && $this->_tpl_vars['rows']['0']['contribution_id']): ?>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Contribute/Form/Selector.tpl", 'smarty_include_vars' => array('context' => 'Search')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      <?php endif; ?>

      <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'bottom')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
    </div>
  </div>
  <?php if ($this->_tpl_vars['action'] == 1 || $this->_tpl_vars['action'] == 2): ?>
    <?php echo '
    <script type="text/javascript">
    // event select
    function buildSelect( selectID, listallVal ) {
      var elementID = \'#\' + selectID;
      cj( elementID ).html(\'\');
      var postUrl = "'; ?>
<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/ajax/eventlist','h' => 0), $this);?>
<?php echo '";
      cj.post( postUrl, {listall:listallVal}, function ( response ) {
        response = eval( response );
        for (i = 0; i < response.length; i++) {
          cj( elementID ).get(0).add(new Option(response[i].name, response[i].value), document.all ? i : null);
        }
        getShowEventInfo(listallVal);
        cj(\'input[name="past_event"]\').val(listallVal);
        cj("#feeBlock").html( \'\' );
      });
    }

    '; ?>

    <?php if ($this->_tpl_vars['action'] == 1): ?>getShowEventInfo(<?php echo $this->_tpl_vars['past']; ?>
);<?php endif; ?>
    <?php echo '

    function getShowEventInfo (listallVal) {
      switch(listallVal) {
        case 1:
          cj(\'#showing-event-info\').html('; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing all events: show<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\' <a href="#" onclick="buildSelect(\\\'event_id\\\', 0); return false;">\'+'; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>current and future<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\'</a> | <a href="#" onclick="buildSelect(\\\'event_id\\\', 2); return false;">\'+'; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>past three months<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\'</a>\');
          break;
        case 2:
          cj(\'#showing-event-info\').html('; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing events since three months ago: show<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\' <a href="#" onclick="buildSelect(\\\'event_id\\\', 0); return false;">\'+'; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>current and future<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\'</a> | <a href="#" onclick="buildSelect(\\\'event_id\\\', 1); return false;">\'+'; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>all<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\'</a>\');
          break;
        default:
          cj(\'#showing-event-info\').html('; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing current and future events: show<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\' <a href="#" onclick="buildSelect(\\\'event_id\\\', 2); return false;">\'+'; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>past three months<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\'</a> | <a href="#" onclick="buildSelect(\\\'event_id\\\', 1); return false;">\'+'; ?>
'<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>all<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '+\'</a>\');
          break;
      }
    }
    '; ?>


    <?php if ($this->_tpl_vars['preloadJSSnippet']): ?>
      <?php echo $this->_tpl_vars['preloadJSSnippet']; ?>

    <?php else: ?>
      //build fee block
      buildFeeBlock( );
    <?php endif; ?>

    <?php echo '
    //build discount block
    if ( document.getElementById(\'discount_id\') ) {
      var discountId  = document.getElementById(\'discount_id\').value;
      if ( discountId ) {
        var eventId  = document.getElementById(\'event_id\').value;
        buildFeeBlock( eventId, discountId );
      }
    }

    function buildFeeBlock( eventId, discountId )  {
      var dataUrl = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => $this->_tpl_vars['urlPath'],'h' => 0,'q' => 'snippet=4'), $this);?>
";
      dataUrl = dataUrl + '&qfKey=' + '<?php echo $this->_tpl_vars['qfKey']; ?>
'

      <?php if ($this->_tpl_vars['urlPathVar']): ?>
        dataUrl = dataUrl + '&' + '<?php echo $this->_tpl_vars['urlPathVar']; ?>
'
      <?php endif; ?>

      <?php echo '
      if ( !eventId ) {
        var eventId  = document.getElementById(\'event_id\').value;
      }

      if ( eventId) {
        dataUrl = dataUrl + \'&eventId=\' + eventId;
      }
      else {
        cj(\'#eventFullMsg\').hide( );
        cj(\'#feeBlock\').html(\'\');
        return;
      }

      var participantId  = "'; ?>
<?php echo $this->_tpl_vars['participantId']; ?>
<?php echo '";

      if ( participantId ) {
        dataUrl = dataUrl + \'&participantId=\' + participantId;
      }

      if ( discountId ) {
        dataUrl = dataUrl + \'&discountId=\' + discountId;
      }

      cj.ajax({
        url: dataUrl,
        async: false,
        global: false,
        success: function ( html ) {
          cj("#feeBlock").html( html );
        }
      });

      cj("#feeBlock").ajaxStart(function(){
        cj(".disable-buttons input").attr(\'disabled\', true);
      });

      cj("#feeBlock").ajaxStop(function(){
        cj(".disable-buttons input").attr(\'disabled\', false);
      });

      //show event real full as well as waiting list message.
      if ( cj("#hidden_eventFullMsg").val( ) ) {
        cj( "#eventFullMsg" ).show( ).html( cj("#hidden_eventFullMsg" ).val( ) );
      }
      else {
        cj( "#eventFullMsg" ).hide( );
      }
    }

  </script>
  '; ?>


    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/customData.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
  <?php echo '
  <script type="text/javascript">
    var roleGroupMapper = new Array( );
    '; ?>

    <?php $_from = $this->_tpl_vars['participantRoleIds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['rlId'] => $this->_tpl_vars['grps']):
?>
    <?php echo '
      roleGroupMapper['; ?>
<?php echo $this->_tpl_vars['rlId']; ?>
<?php echo '] = \''; ?>
<?php echo $this->_tpl_vars['grps']; ?>
<?php echo '\';
    '; ?>

    <?php endforeach; endif; unset($_from); ?>
    <?php echo '

    function buildParticipantRole( eventID ) {
      var dataUrl = "'; ?>
<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/ajax/rest','q' => 'className=CRM_Event_Page_AJAX&fnName=participantRole&json=1&context=participant','h' => 0), $this);?>
"<?php echo ';

      if ( !eventId ) {
        var eventId  = document.getElementById( \'event_id\' ).value;
      }

      if ( eventId ) {
        dataUrl = dataUrl + \'&eventId=\' + eventID;
      }

      cj.ajax({
        url: dataUrl,
        async: false,
        global: false,
        dataType: "json",
        success: function ( response ) {
          if ( response.role ) {
            for ( var i in roleGroupMapper ) {
              if ( i != 0 ) {
                if ( i == response.role ) {
                  document.getElementById("role_id_" +i  ).checked = true;
                }
                else {
                  document.getElementById("role_id_" +i  ).checked = false;
                }
                showCustomData( \'Participant\', i, '; ?>
 <?php echo $this->_tpl_vars['roleCustomDataTypeID']; ?>
 <?php echo ' );
              }
            }
          }
        }
      });
    }

    function showCustomData( type, subType, subName ) {
      var dataUrl = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => $this->_tpl_vars['urlPath'],'h' => 0,'q' => 'snippet=4&type='), $this);?>
"<?php echo ' + type;
      var roleid = "role_id_"+subType;
      var loadData = false;

      if ( document.getElementById( roleid ).checked == true ) {
        if ( roleGroupMapper[subType] ) {
          var splitGroup = roleGroupMapper[subType].split(",");
          for ( i = 0; i < splitGroup.length; i++ ) {
            var roleCustomGroupId = splitGroup[i];
            if ( cj( \'#\'+roleCustomGroupId ).length > 0 ) {
              cj( \'#\'+roleCustomGroupId ).remove( );
            }
          }
          loadData = true;
        }
      }
      else {
        var groupUnload = new Array( );
        var x = 0;

        if ( roleGroupMapper[0] ) {
          var splitGroup = roleGroupMapper[0].split(",");
          for ( x = 0; x < splitGroup.length; x++ ) {
            groupUnload[x] = splitGroup[x];
          }
        }

        for ( var i in roleGroupMapper ) {
          if ( ( i > 0 ) && ( document.getElementById( "role_id_"+i ).checked ) ) {
            var splitGroup = roleGroupMapper[i].split(",");
            for ( j = 0; j < splitGroup.length; j++ ) {
              groupUnload[x+j+1] = splitGroup[j];
            }
          }
        }

        if ( roleGroupMapper[subType] ) {
          var splitGroup = roleGroupMapper[subType].split(",");
          for ( i = 0; i < splitGroup.length; i++ ) {
            var roleCustomGroupId = splitGroup[i];
            if ( cj( \'#\'+roleCustomGroupId ).length > 0 ) {
              if ( cj.inArray( roleCustomGroupId, groupUnload ) == -1  ) {
                cj( \'#\'+roleCustomGroupId ).remove( );
              }
            }
          }
        }
      }

      if ( !( loadData ) ) {
        return false;
      }

      if ( subType ) {
        dataUrl = dataUrl + \'&subType=\' + subType;
      }

      if ( subName ) {
        dataUrl = dataUrl + \'&subName=\' + subName;
        cj( \'#customData\' + subName ).show( );
      }
      else {
        cj( \'#customData\' ).show( );
      }

      '; ?>

      <?php if ($this->_tpl_vars['urlPathVar']): ?>
        dataUrl = dataUrl + '&' + '<?php echo $this->_tpl_vars['urlPathVar']; ?>
'
      <?php endif; ?>
      <?php if ($this->_tpl_vars['groupID']): ?>
        dataUrl = dataUrl + '&groupID=' + '<?php echo $this->_tpl_vars['groupID']; ?>
'
      <?php endif; ?>
      <?php if ($this->_tpl_vars['qfKey']): ?>
        dataUrl = dataUrl + '&qfKey=' + '<?php echo $this->_tpl_vars['qfKey']; ?>
'
      <?php endif; ?>
      <?php if ($this->_tpl_vars['entityID']): ?>
        dataUrl = dataUrl + '&entityID=' + '<?php echo $this->_tpl_vars['entityID']; ?>
'
      <?php endif; ?>

      <?php echo '

      if ( subName && subName != \'null\' ) {
        var fname = \'#customData\' + subName;
      }
      else {
        var fname = \'#customData\';
      }

      var response = cj.ajax({url: dataUrl,
        async: false
      }).responseText;

      if ( subType != \'null\' ) {
        if ( document.getElementById(roleid).checked == true ) {
          var response_text = \'<div style="display:block;" id = \'+subType+\'_chk >\'+response+\'</div>\';
          cj( fname ).append(response_text);
        }
        else {
          cj(\'#\'+subType+\'_chk\').remove();
        }
      }
    }

    cj(function() {
      '; ?>

      CRM.buildCustomData( '<?php echo $this->_tpl_vars['customDataType']; ?>
', 'null', 'null' );
      <?php echo '
      for ( var i in roleGroupMapper ) {
        if ( ( i > 0 ) && ( document.getElementById( "role_id_"+i ).checked ) ) {
        '; ?>

        showCustomData( '<?php echo $this->_tpl_vars['customDataType']; ?>
', i, <?php echo $this->_tpl_vars['roleCustomDataTypeID']; ?>
 );
        <?php echo '
        }
      }
      '; ?>

      <?php if ($this->_tpl_vars['eventID']): ?>
        CRM.buildCustomData( '<?php echo $this->_tpl_vars['customDataType']; ?>
', <?php echo $this->_tpl_vars['eventID']; ?>
, <?php echo $this->_tpl_vars['eventNameCustomDataTypeID']; ?>
 );
      <?php endif; ?>
      <?php if ($this->_tpl_vars['eventTypeID']): ?>
        CRM.buildCustomData( '<?php echo $this->_tpl_vars['customDataType']; ?>
', <?php echo $this->_tpl_vars['eventTypeID']; ?>
, <?php echo $this->_tpl_vars['eventTypeCustomDataTypeID']; ?>
 );
      <?php endif; ?>
      <?php echo '

      //call pane js
      cj().crmAccordions();
    });
    </script>
    '; ?>


  <?php endif; ?>

    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formNavigate.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<script type="text/javascript">
  <?php echo '

  sendNotification();
  function sendNotification() {
    var notificationStatusIds = '; ?>
"<?php echo $this->_tpl_vars['notificationStatusIds']; ?>
"<?php echo ';
    notificationStatusIds = notificationStatusIds.split(\',\');
    if (cj.inArray(cj(\'select#status_id option:selected\').val(), notificationStatusIds) > -1) {
      cj("#notify").show();
      cj("#is_notify").attr(\'checked\', true);
    }
    else {
      cj("#notify").hide();
      cj("#is_notify").removeAttr(\'checked\');
    }
  }

  function buildEventTypeCustomData( eventID, eventTypeCustomDataTypeID, eventAndTypeMapping ) {
    var mapping = eval(\'(\' + eventAndTypeMapping + \')\');
    CRM.buildCustomData( \'Participant\', mapping[eventID], eventTypeCustomDataTypeID );
  }

  function loadCampaign( eventId, campaigns ) {
    cj( "#campaign_id" ).val( campaigns[eventId] );
  }

  '; ?>

  <?php if ($this->_tpl_vars['profileCreateCallback']): ?>
    <?php echo '
    function profileCreateCallback( blockNo ) {
      if( cj(\'#event_id\').val( ) &&  cj(\'#email-receipt\').length > 0 ) {
        checkEmail( );
      }
    }
    '; ?>

  <?php endif; ?>
</script>
<?php echo '
<script type="text/javascript">
  cj(function() {
    cj().crmAccordions();
  });
</script>
'; ?>


<?php endif; ?> 
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>