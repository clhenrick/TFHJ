<?php /* Smarty version 2.6.27, created on 2014-06-20 14:01:07
         compiled from CRM/Event/Form/ParticipantView.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Event/Form/ParticipantView.tpl', 1, false),array('block', 'ts', 'CRM/Event/Form/ParticipantView.tpl', 28, false),array('function', 'crmURL', 'CRM/Event/Form/ParticipantView.tpl', 36, false),array('modifier', 'crmDate', 'CRM/Event/Form/ParticipantView.tpl', 92, false),array('modifier', 'crmMoney', 'CRM/Event/Form/ParticipantView.tpl', 109, false),array('modifier', 'nl2br', 'CRM/Event/Form/ParticipantView.tpl', 115, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><div class="crm-block crm-content-block crm-event-participant-view-form-block">
    <h3><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>View Participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></h3>
    <div class="action-link">
        <div class="crm-submit-buttons">
            <?php if (call_user_func ( array ( 'CRM_Core_Permission' , 'check' ) , 'edit event participants' )): ?>
         <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=update&context=".($this->_tpl_vars['context'])."&selectedChild=event"); ?>
         <?php if (( $this->_tpl_vars['context'] == 'fulltext' || $this->_tpl_vars['context'] == 'search' ) && $this->_tpl_vars['searchKey']): ?>
         <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=update&context=".($this->_tpl_vars['context'])."&selectedChild=event&key=".($this->_tpl_vars['searchKey'])); ?>
         <?php endif; ?>
               <a class="button" href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view/participant','q' => $this->_tpl_vars['urlParams']), $this);?>
" accesskey="e"><span><div class="icon edit-icon"></div> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Edit<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a>
            <?php endif; ?>
            <?php if (call_user_func ( array ( 'CRM_Core_Permission' , 'check' ) , 'delete in CiviEvent' )): ?>
                <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=delete&context=".($this->_tpl_vars['context'])."&selectedChild=event"); ?>
          <?php if (( $this->_tpl_vars['context'] == 'fulltext' || $this->_tpl_vars['context'] == 'search' ) && $this->_tpl_vars['searchKey']): ?>
          <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=delete&context=".($this->_tpl_vars['context'])."&selectedChild=event&key=".($this->_tpl_vars['searchKey'])); ?>
          <?php endif; ?>
                <a class="button" href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view/participant','q' => $this->_tpl_vars['urlParams']), $this);?>
"><span><div class="icon delete-icon"></div> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Delete<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a>
            <?php endif; ?>
            <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'top')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        </div>
    </div>
    <table class="crm-info-panel">
    <tr class="crm-event-participantview-form-block-displayName">
      <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Participant Name<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
      <td class="bold">
        <a href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view','q' => "reset=1&cid=".($this->_tpl_vars['contact_id'])), $this);?>
" title="view contact record"><?php echo $this->_tpl_vars['displayName']; ?>
</a>
        <div class="crm-submit-buttons">
            <a class="button" href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/event/badge','q' => "reset=1&context=view&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])), $this);?>
" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Print Event Name Badge<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"><span><div class="icon print-icon"></div> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Print Name Badge<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a>
        </div>
      </td>
  </tr>
  <?php if ($this->_tpl_vars['participant_registered_by_id']): ?>       <tr class="crm-event-participantview-form-block-registeredBy">
          <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Registered By<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
          <td><a href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view/participant','q' => "reset=1&id=".($this->_tpl_vars['participant_registered_by_id'])."&cid=".($this->_tpl_vars['registered_by_contact_id'])."&action=view"), $this);?>
" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>view primary participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"><?php echo $this->_tpl_vars['registered_by_display_name']; ?>
</a></td>
      </tr>
  <?php endif; ?>
  <?php if ($this->_tpl_vars['additionalParticipants']): ?>         <tr class="crm-event-participantview-form-block-additionalParticipants">
            <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Also Registered by this Participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
            <td>
                <?php $_from = $this->_tpl_vars['additionalParticipants']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['apName'] => $this->_tpl_vars['apURL']):
?>
                    <a href="<?php echo $this->_tpl_vars['apURL']; ?>
" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>view additional participant<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"><?php echo $this->_tpl_vars['apName']; ?>
</a><br />
                <?php endforeach; endif; unset($_from); ?>
            </td>
        </tr>
  <?php endif; ?>
    <tr class="crm-event-participantview-form-block-event">
      <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Event<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td><td>
        <a href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/event/manage/settings','q' => "action=update&reset=1&id=".($this->_tpl_vars['event_id'])), $this);?>
" title="<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Configure this event<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"><?php echo $this->_tpl_vars['event']; ?>
</a>
      </td>
  </tr>

    <?php if ($this->_tpl_vars['campaign']): ?>
    <tr class="crm-event-participantview-form-block-campaign">
      <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Campaign<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
      <td><?php echo $this->_tpl_vars['campaign']; ?>
</td>
    </tr>
    <?php endif; ?>

    <tr class="crm-event-participantview-form-block-role">
      <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Participant Role<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
      <td><?php echo $this->_tpl_vars['role']; ?>
</td></tr>
        <tr class="crm-event-participantview-form-block-register_date">
      <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Registration Date and Time<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
      <td><?php echo ((is_array($_tmp=$this->_tpl_vars['register_date'])) ? $this->_run_mod_handler('crmDate', true, $_tmp) : smarty_modifier_crmDate($_tmp)); ?>
&nbsp;</td>
  </tr>
    <tr class="crm-event-participantview-form-block-status">
      <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Status<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td><td><?php echo $this->_tpl_vars['status']; ?>
&nbsp;</td>
  </tr>
    <?php if ($this->_tpl_vars['source']): ?>
        <tr class="crm-event-participantview-form-block-event_source">
        <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Event Source<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td><td><?php echo $this->_tpl_vars['source']; ?>
&nbsp;</td>
      </tr>
    <?php endif; ?>
    <?php if ($this->_tpl_vars['fee_level']): ?>
        <tr class="crm-event-participantview-form-block-fee_amount">
            <?php if ($this->_tpl_vars['lineItem']): ?>
                <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Event Fees<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
                <td><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Price/Page/LineItem.tpl", 'smarty_include_vars' => array('context' => 'Event')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></td>
            <?php else: ?>
                <td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Event Level<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td>
                <td><?php echo $this->_tpl_vars['fee_level']; ?>
&nbsp;<?php if ($this->_tpl_vars['fee_amount']): ?>- <?php echo ((is_array($_tmp=$this->_tpl_vars['fee_amount'])) ? $this->_run_mod_handler('crmMoney', true, $_tmp, $this->_tpl_vars['fee_currency']) : smarty_modifier_crmMoney($_tmp, $this->_tpl_vars['fee_currency'])); ?>
<?php endif; ?></td>
            <?php endif; ?>
        </tr>
    <?php endif; ?>
    <?php $_from = $this->_tpl_vars['note']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['rec']):
?>
      <?php if ($this->_tpl_vars['rec']): ?>
            <tr><td class="label"><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Note<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></td><td><?php echo ((is_array($_tmp=$this->_tpl_vars['rec'])) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
</td></tr>
      <?php endif; ?>
    <?php endforeach; endif; unset($_from); ?>
    </table>
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Custom/Page/CustomDataView.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    <?php if ($this->_tpl_vars['accessContribution'] && $this->_tpl_vars['rows']['0']['contribution_id']): ?>
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Contribute/Form/Selector.tpl", 'smarty_include_vars' => array('context' => 'Search')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    <?php endif; ?>
    <div class="crm-submit-buttons">
        <?php if (call_user_func ( array ( 'CRM_Core_Permission' , 'check' ) , 'edit event participants' )): ?>
    <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=update&context=".($this->_tpl_vars['context'])."&selectedChild=event"); ?>
    <?php if (( $this->_tpl_vars['context'] == 'fulltext' || $this->_tpl_vars['context'] == 'search' ) && $this->_tpl_vars['searchKey']): ?>
    <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=update&context=".($this->_tpl_vars['context'])."&selectedChild=event&key=".($this->_tpl_vars['searchKey'])); ?>
    <?php endif; ?>

           <a class="button" href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view/participant','q' => $this->_tpl_vars['urlParams']), $this);?>
" accesskey="e"><span><div class="icon edit-icon"></div> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Edit<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a>
        <?php endif; ?>
        <?php if (call_user_func ( array ( 'CRM_Core_Permission' , 'check' ) , 'delete in CiviEvent' )): ?>
    <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=delete&context=".($this->_tpl_vars['context'])."&selectedChild=event"); ?>
    <?php if (( $this->_tpl_vars['context'] == 'fulltext' || $this->_tpl_vars['context'] == 'search' ) && $this->_tpl_vars['searchKey']): ?>
    <?php $this->assign('urlParams', "reset=1&id=".($this->_tpl_vars['id'])."&cid=".($this->_tpl_vars['contact_id'])."&action=delete&context=".($this->_tpl_vars['context'])."&selectedChild=event&key=".($this->_tpl_vars['searchKey'])); ?>
    <?php endif; ?>
            <a class="button" href="<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/contact/view/participant','q' => $this->_tpl_vars['urlParams']), $this);?>
"><span><div class="icon delete-icon"></div> <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Delete<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></span></a>
        <?php endif; ?>
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'bottom')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    </div>
</div>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>