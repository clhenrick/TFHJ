<?php /* Smarty version 2.6.27, created on 2014-08-01 12:28:38
         compiled from CRM/Financial/Form/Export.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Financial/Form/Export.tpl', 1, false),array('block', 'ts', 'CRM/Financial/Form/Export.tpl', 27, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><h3><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Export Batch<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></h3>
<div class="messages status">
  <div class="icon inform-icon"></div>
  <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Warning: You will not be able to reopen or change the batch after it is exported. Are you sure you want to export?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
</div>
<div class="crm-block crm-form-block crm-export_batch-form-block">
  <div class = "batch-names">
    <ul>
    <?php $_from = $this->_tpl_vars['batchNames']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['batchName']):
?>
      <li><?php echo $this->_tpl_vars['batchName']; ?>
</li>
    <?php endforeach; endif; unset($_from); ?>
    </ul>
  </div>

  <table class="form-layout">
    <tr class="crm-contribution-form-block-name">
      <td class="html-adjust">
      <?php echo $this->_tpl_vars['form']['export_format']['html']; ?>

      </td>
    </tr>
  </table>

  <div class="form-item">
  <?php echo $this->_tpl_vars['form']['buttons']['html']; ?>

  </div>
</div>
<?php echo '
<script type="text/javascript">
  cj(function(){
    cj(\'input[name="export_format"]\').filter(\'[value=IIF]\').attr(\'checked\', true);
    cj(\'#_qf_Export_next\').click(function(){
      cj(this).hide();
      cj(\'#_qf_Export_cancel\').val(\''; ?>
<?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Done<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '\');
    });
  });
</script>
'; ?>


<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>