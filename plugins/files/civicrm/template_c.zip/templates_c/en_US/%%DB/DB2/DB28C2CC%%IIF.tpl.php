<?php /* Smarty version 2.6.27, created on 2014-08-01 12:28:42
         compiled from CRM/Financial/ExportFormat/IIF.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Financial/ExportFormat/IIF.tpl', 1, false),array('modifier', 'chr', 'CRM/Financial/ExportFormat/IIF.tpl', 39, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php $this->assign('tabchar', ((is_array($_tmp=9)) ? $this->_run_mod_handler('chr', true, $_tmp) : chr($_tmp))); ?>
<?php if (! empty ( $this->_tpl_vars['accounts'] )): ?>
!ACCNT<?php echo $this->_tpl_vars['tabchar']; ?>
NAME<?php echo $this->_tpl_vars['tabchar']; ?>
REFNUM<?php echo $this->_tpl_vars['tabchar']; ?>
TIMESTAMP<?php echo $this->_tpl_vars['tabchar']; ?>
ACCNTTYPE<?php echo $this->_tpl_vars['tabchar']; ?>
OBAMOUNT<?php echo $this->_tpl_vars['tabchar']; ?>
DESC<?php echo $this->_tpl_vars['tabchar']; ?>
ACCNUM
<?php $_from = $this->_tpl_vars['accounts']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['account_id'] => $this->_tpl_vars['acct']):
?>
ACCNT<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['acct']['name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['acct']['type']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['acct']['description']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['acct']['account_code']; ?>

<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
<?php if (! empty ( $this->_tpl_vars['contacts'] )): ?>
!CUST<?php echo $this->_tpl_vars['tabchar']; ?>
NAME<?php echo $this->_tpl_vars['tabchar']; ?>
REFNUM<?php echo $this->_tpl_vars['tabchar']; ?>
TIMESTAMP<?php echo $this->_tpl_vars['tabchar']; ?>
BADDR1<?php echo $this->_tpl_vars['tabchar']; ?>
BADDR2<?php echo $this->_tpl_vars['tabchar']; ?>
BADDR3<?php echo $this->_tpl_vars['tabchar']; ?>
BADDR4<?php echo $this->_tpl_vars['tabchar']; ?>
BADDR5<?php echo $this->_tpl_vars['tabchar']; ?>
SADDR1<?php echo $this->_tpl_vars['tabchar']; ?>
SADDR2<?php echo $this->_tpl_vars['tabchar']; ?>
SADDR3<?php echo $this->_tpl_vars['tabchar']; ?>
SADDR4<?php echo $this->_tpl_vars['tabchar']; ?>
SADDR5<?php echo $this->_tpl_vars['tabchar']; ?>
PHONE1<?php echo $this->_tpl_vars['tabchar']; ?>
PHONE2<?php echo $this->_tpl_vars['tabchar']; ?>
FAXNUM<?php echo $this->_tpl_vars['tabchar']; ?>
EMAIL<?php echo $this->_tpl_vars['tabchar']; ?>
NOTE<?php echo $this->_tpl_vars['tabchar']; ?>
CONT1<?php echo $this->_tpl_vars['tabchar']; ?>
CONT2<?php echo $this->_tpl_vars['tabchar']; ?>
CTYPE<?php echo $this->_tpl_vars['tabchar']; ?>
TERMS<?php echo $this->_tpl_vars['tabchar']; ?>
TAXABLE<?php echo $this->_tpl_vars['tabchar']; ?>
SALESTAXCODE<?php echo $this->_tpl_vars['tabchar']; ?>
LIMIT<?php echo $this->_tpl_vars['tabchar']; ?>
RESALENUM<?php echo $this->_tpl_vars['tabchar']; ?>
REP<?php echo $this->_tpl_vars['tabchar']; ?>
TAXITEM<?php echo $this->_tpl_vars['tabchar']; ?>
NOTEPAD<?php echo $this->_tpl_vars['tabchar']; ?>
SALUTATION<?php echo $this->_tpl_vars['tabchar']; ?>
COMPANYNAME<?php echo $this->_tpl_vars['tabchar']; ?>
FIRSTNAME<?php echo $this->_tpl_vars['tabchar']; ?>
MIDINIT<?php echo $this->_tpl_vars['tabchar']; ?>
LASTNAME<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD1<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD2<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD3<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD4<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD5<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD6<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD7<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD8<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD9<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD10<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD11<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD12<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD13<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD14<?php echo $this->_tpl_vars['tabchar']; ?>
CUSTFLD15<?php echo $this->_tpl_vars['tabchar']; ?>
JOBDESC<?php echo $this->_tpl_vars['tabchar']; ?>
JOBTYPE<?php echo $this->_tpl_vars['tabchar']; ?>
JOBSTATUS<?php echo $this->_tpl_vars['tabchar']; ?>
JOBSTART<?php echo $this->_tpl_vars['tabchar']; ?>
JOBPROJEND<?php echo $this->_tpl_vars['tabchar']; ?>
JOBEND<?php echo $this->_tpl_vars['tabchar']; ?>
HIDDEN<?php echo $this->_tpl_vars['tabchar']; ?>
DELCOUNT<?php echo $this->_tpl_vars['tabchar']; ?>
PRICELEVEL
<?php $_from = $this->_tpl_vars['contacts']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['contact_id'] => $this->_tpl_vars['contact']):
?>
CUST<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['contact']['name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['contact']['first_name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['contact']['last_name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>

<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
<?php if (! empty ( $this->_tpl_vars['journalEntries'] )): ?>
!TRNS<?php echo $this->_tpl_vars['tabchar']; ?>
TRNSID<?php echo $this->_tpl_vars['tabchar']; ?>
TRNSTYPE<?php echo $this->_tpl_vars['tabchar']; ?>
DATE<?php echo $this->_tpl_vars['tabchar']; ?>
ACCNT<?php echo $this->_tpl_vars['tabchar']; ?>
NAME<?php echo $this->_tpl_vars['tabchar']; ?>
CLASS<?php echo $this->_tpl_vars['tabchar']; ?>
AMOUNT<?php echo $this->_tpl_vars['tabchar']; ?>
DOCNUM<?php echo $this->_tpl_vars['tabchar']; ?>
MEMO<?php echo $this->_tpl_vars['tabchar']; ?>
PAYMETH
!SPL<?php echo $this->_tpl_vars['tabchar']; ?>
SPLID<?php echo $this->_tpl_vars['tabchar']; ?>
TRNSTYPE<?php echo $this->_tpl_vars['tabchar']; ?>
DATE<?php echo $this->_tpl_vars['tabchar']; ?>
ACCNT<?php echo $this->_tpl_vars['tabchar']; ?>
NAME<?php echo $this->_tpl_vars['tabchar']; ?>
CLASS<?php echo $this->_tpl_vars['tabchar']; ?>
AMOUNT<?php echo $this->_tpl_vars['tabchar']; ?>
DOCNUM<?php echo $this->_tpl_vars['tabchar']; ?>
MEMO<?php echo $this->_tpl_vars['tabchar']; ?>
PAYMETH
!ENDTRNS
<?php $_from = $this->_tpl_vars['journalEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['id'] => $this->_tpl_vars['je']):
?>
TRNS<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['trxn_id']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
GENERAL JOURNAL<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['trxn_date']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['account_name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['contact_name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['amount']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['check_number']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['je']['to_account']['payment_instrument']; ?>

<?php $_from = $this->_tpl_vars['je']['splits']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['spl_id'] => $this->_tpl_vars['spl']):
?>
SPL<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['spl_id']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
GENERAL JOURNAL<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['trxn_date']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['account_name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['contact_name']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['amount']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['check_number']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['description']; ?>
<?php echo $this->_tpl_vars['tabchar']; ?>
<?php echo $this->_tpl_vars['spl']['payment_instrument']; ?>

<?php endforeach; endif; unset($_from); ?>
ENDTRNS
<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>