<?php /* Smarty version 2.6.27, created on 2014-08-01 12:27:47
         compiled from CRM/Financial/Page/BatchTransaction.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Financial/Page/BatchTransaction.tpl', 1, false),array('block', 'ts', 'CRM/Financial/Page/BatchTransaction.tpl', 60, false),array('function', 'crmURL', 'CRM/Financial/Page/BatchTransaction.tpl', 143, false),array('function', 'crmKey', 'CRM/Financial/Page/BatchTransaction.tpl', 145, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>
<div id="enableDisableStatusMsg" class="crm-container" style="display:none;"></div>
<table id="batch-summary" cellpadding="0" cellspacing="0" border="0" class="report crm-batch_summary">
  <thead class="sticky">
    <tr>
     <?php $_from = $this->_tpl_vars['columnHeaders']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['head']):
?>
       <th><?php echo $this->_tpl_vars['head']; ?>
</th>
     <?php endforeach; endif; unset($_from); ?>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php $_from = $this->_tpl_vars['columnHeaders']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['rowKey'] => $this->_tpl_vars['head']):
?>
        <td id="row_<?php echo $this->_tpl_vars['rowKey']; ?>
" class="even-row"></td>
      <?php endforeach; endif; unset($_from); ?>
    </tr>
  </tbody>
</table>

<div class="crm-submit-buttons"><?php if ($this->_tpl_vars['statusID'] == 1): ?><?php echo $this->_tpl_vars['form']['close_batch']['html']; ?>
<?php endif; ?> <?php echo $this->_tpl_vars['form']['export_batch']['html']; ?>
</div>

<?php if ($this->_tpl_vars['statusID'] == 1): ?>   <br /><div class="form-layout-compressed"><?php echo $this->_tpl_vars['form']['trans_remove']['html']; ?>
&nbsp;<?php echo $this->_tpl_vars['form']['rSubmit']['html']; ?>
</div><br/>
<?php endif; ?>

<div id="ltype">
  <p></p>
  <div class="form-item">
  <?php echo '<table id="crm-transaction-selector-remove" cellpadding="0" cellspacing="0" border="0"><thead><tr><th class="crm-transaction-checkbox">'; ?><?php if ($this->_tpl_vars['statusID'] == 1): ?><?php echo ''; ?><?php echo $this->_tpl_vars['form']['toggleSelects']['html']; ?><?php echo ''; ?><?php endif; ?><?php echo '</th><th class="crm-contact-type"></th><th class="crm-contact-name">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Name'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-amount">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Amount'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-trxnID">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Trxn ID'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-received">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Received'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-payment-method">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Pay Method'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-status">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Status'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-type">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Type'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-transaction-links"></th></tr></thead></table>'; ?>

  </div>
</div>
<br/>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Financial/Form/BatchTransaction.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php echo '
<script type="text/javascript">
cj( function() {
  var entityID = '; ?>
<?php echo $this->_tpl_vars['entityID']; ?>
<?php echo ';
  batchSummary(entityID);
  cj(\'#close_batch\').click( function() {
    assignRemove(entityID, \'close\');
    return false;
  });
  cj(\'#export_batch\').click( function() {
    assignRemove(entityID, \'export\');
    return false;
  });
});
function assignRemove(recordID, op) {
  var recordBAO = \'CRM_Batch_BAO_Batch\';
  var entityID = '; ?>
"<?php echo $this->_tpl_vars['entityID']; ?>
"<?php echo ';
  if (op == \'close\' || op == \'export\') {
    var mismatch = checkMismatch();
  }
  else {
    cj(\'#mark_x_\' + recordID).closest(\'tr\').block({message: '; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Updating<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo '});
  }
  if (op == \'close\' || (op == \'export\' && mismatch.length)) {
    cj("#enableDisableStatusMsg").dialog({
      title: '; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Close Batch<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo ',
      modal: true,
      bgiframe: true,
      overlay: {
        opacity: 0.5,
        background: "black"
      },
      open:function() {
        if (op == \'close\') {
          var msg = '; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Are you sure you want to close this batch?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo ';
        }
        else {
          var msg = '; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Are you sure you want to close and export this batch?<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo ';
        }
        cj(\'#enableDisableStatusMsg\').show().html(msg + mismatch);
      },
      buttons: {
        '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Cancel<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ': function() {
          cj(this).dialog("close");
        },
        '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>OK<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ': function() {
          cj(this).dialog("close");
          saveRecord(recordID, op, recordBAO, entityID);
        }
      }
    });
  }
  else {
    saveRecord(recordID, op, recordBAO, entityID);
  }
}

function noServerResponse() {
  CRM.alert('; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>No response from the server. Check your internet connection and try reloading the page.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>', '<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Network Error<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo ', \'error\');
}

function saveRecord(recordID, op, recordBAO, entityID) {
  if (op == \'export\') {
    window.location.href = CRM.url(\'civicrm/financial/batch/export\', {reset: 1, id: recordID, status: 1});
    return;
  }
  var postUrl = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/ajax/rest','h' => 0,'q' => 'className=CRM_Financial_Page_AJAX&fnName=assignRemove'), $this);?>
"<?php echo ';
  //post request and get response
  cj.post( postUrl, { records: [recordID], recordBAO: recordBAO, op:op, entityID:entityID, key: '; ?>
"<?php echo smarty_function_crmKey(array('name' => 'civicrm/ajax/ar'), $this);?>
"<?php echo '  }, function( html ){
    //this is custom status set when record update success.
    if (html.status == \'record-updated-success\') {
       if (op == \'close\') {
         window.location.href = CRM.url(\'civicrm/financial/financialbatches\', \'reset=1&batchStatus=2\');
       }
       else {
         buildTransactionSelectorAssign( true );
         buildTransactionSelectorRemove();
         batchSummary(entityID);
       }
    }
    else {
      CRM.alert(html.status);
    }
  },
  \'json\').error(noServerResponse);
}

function batchSummary(entityID) {
  var postUrl = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/ajax/rest','h' => 0,'q' => 'className=CRM_Financial_Page_AJAX&fnName=getBatchSummary'), $this);?>
"<?php echo ';
  //post request and get response
  cj.post( postUrl, {batchID: entityID}, function(html) {
    cj.each(html, function(i, val) {
      cj("#row_" + i).html(val);
    });
  },
  \'json\');
}

function checkMismatch() {
  var txt = \'\';
  var enteredItem = cj("#row_item_count").text();
  var assignedItem = cj("#row_assigned_item_count").text();
  var enteredTotal = cj("#row_total").text();
  var assignedTotal = cj("#row_assigned_total").text();
  if (enteredItem != "" && enteredItem != assignedItem) {
     txt = \''; ?>
<div class="messages crm-error"><strong>Item Count mismatch:</strong><br/><?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Expected<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>:' + enteredItem +'<br/><?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Current Total<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>:' + assignedItem + '</div><?php echo '\';
  }
  if (enteredTotal != "" && enteredTotal != assignedTotal) {
     txt += \''; ?>
<div class="messages crm-error"><strong>Total Amount mismatch</strong><br/><?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Expected<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>:' + enteredTotal +'<br/><?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Current Total<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>:' + assignedTotal + '</div><?php echo '\';
  }
  if (txt.length) {
    txt += '; ?>
'<div class="messages status"><?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Click OK to override and update expected values.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></div>'<?php echo '
  }
  return txt;
}
</script>
'; ?>

<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>