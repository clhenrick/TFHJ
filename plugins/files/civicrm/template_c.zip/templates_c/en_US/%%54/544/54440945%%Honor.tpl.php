<?php /* Smarty version 2.6.27, created on 2014-07-08 17:07:15
         compiled from CRM/Contribute/Form/Contribution/Honor.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Contribute/Form/Contribution/Honor.tpl', 1, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php if ($this->_tpl_vars['honor_block_is_active']): ?>
<div class="crm-group honor_block-group">
    <div class="header-dark">
        <?php echo $this->_tpl_vars['honor_block_title']; ?>

    </div>
    <div class="display-block">
         <strong><?php echo $this->_tpl_vars['honor_type']; ?>
  : </strong>
         <?php echo $this->_tpl_vars['honor_prefix']; ?>
&nbsp;<?php echo $this->_tpl_vars['honor_first_name']; ?>
&nbsp;<?php echo $this->_tpl_vars['honor_last_name']; ?>
<br />
         <strong>Email      : </strong><?php echo $this->_tpl_vars['honor_email']; ?>
<br />
    </div>
</div>
<?php endif; ?>
<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>