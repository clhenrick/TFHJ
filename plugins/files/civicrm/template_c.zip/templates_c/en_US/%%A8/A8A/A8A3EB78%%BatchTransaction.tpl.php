<?php /* Smarty version 2.6.27, created on 2014-08-01 12:27:47
         compiled from CRM/Financial/Form/BatchTransaction.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('block', 'crmScope', 'CRM/Financial/Form/BatchTransaction.tpl', 1, false),array('block', 'ts', 'CRM/Financial/Form/BatchTransaction.tpl', 31, false),array('modifier', 'crmAddClass', 'CRM/Financial/Form/BatchTransaction.tpl', 38, false),array('function', 'crmURL', 'CRM/Financial/Form/BatchTransaction.tpl', 202, false),)), $this); ?>
<?php $this->_tag_stack[] = array('crmScope', array('extensionKey' => "")); $_block_repeat=true;smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php if ($this->_tpl_vars['statusID'] == 1): ?>
<div class="crm-form-block crm-search-form-block">
  <div class="crm-accordion-wrapper crm-batch_transaction_search-accordion collapsed">
    <div class="crm-accordion-header crm-master-accordion-header">
      <?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Edit Search Criteria<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>
    </div>
    <div class="crm-accordion-body">
      <div id="searchForm" class="crm-block crm-form-block crm-contact-custom-search-activity-search-form-block">
        <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'top')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
        <table class="form-layout-compressed">
          <tr>
            <td class="font-size12pt" colspan="2"><?php echo $this->_tpl_vars['form']['sort_name']['label']; ?>
&nbsp;&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['form']['sort_name']['html'])) ? $this->_run_mod_handler('crmAddClass', true, $_tmp, 'twenty') : smarty_modifier_crmAddClass($_tmp, 'twenty')); ?>
</td>
          </tr>
          <tr>
          <?php if ($this->_tpl_vars['form']['contact_tags']): ?>
            <td><label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Contributor Tag(s)<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label>
              <?php echo $this->_tpl_vars['form']['contact_tags']['html']; ?>

              <?php echo '
                <script type="text/javascript">
                  cj("select#contact_tags").crmasmSelect({
                    addItemTarget: \'bottom\',
                    animate: false,
                    highlight: true,
                    sortable: true,
                    respectParents: true
                  });
                </script>
              '; ?>

            </td>
            <?php else: ?>
            <td>&nbsp;</td>
          <?php endif; ?>
          <?php if ($this->_tpl_vars['form']['group']): ?>
            <td><label><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Contributor Group(s)<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?></label>
              <?php echo $this->_tpl_vars['form']['group']['html']; ?>

              <?php echo '
                <script type="text/javascript">
                  cj("select#group").crmasmSelect({
                    addItemTarget: \'bottom\',
                    animate: false,
                    highlight: true,
                    sortable: true,
                    respectParents: true
                  });

                </script>
              '; ?>

            </td>
            <?php else: ?>
            <td>&nbsp;</td>
          <?php endif; ?>
          <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/Contribute/Form/Search/Common.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        </table>
        <div class="crm-submit-buttons"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "CRM/common/formButtons.tpl", 'smarty_include_vars' => array('location' => 'botttom')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?></div>
      </div>
    </div>
  </div>
</div>
<?php if ($this->_tpl_vars['statusID'] == 1): ?>
<div class="form-layout-compressed"><?php echo $this->_tpl_vars['form']['trans_assign']['html']; ?>
&nbsp;<?php echo $this->_tpl_vars['form']['submit']['html']; ?>
</div><br/>
<?php endif; ?>
<div id="ltype">
  <p></p>
  <div class="form-item">
  <?php echo '<table id="crm-transaction-selector-assign" cellpadding="0" cellspacing="0" border="0"><thead><tr><th class="crm-transaction-checkbox">'; ?><?php if ($this->_tpl_vars['statusID'] == 1): ?><?php echo ''; ?><?php echo $this->_tpl_vars['form']['toggleSelect']['html']; ?><?php echo ''; ?><?php endif; ?><?php echo '</th><th class="crm-contact-type"></th><th class="crm-contact-name">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Name'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-amount">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Amount'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-trxnID">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Trxn ID'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-received">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Received'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-payment-method">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Pay Method'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-status">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Status'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-type">'; ?><?php $this->_tag_stack[] = array('ts', array()); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?><?php echo 'Financial Type'; ?><?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</th><th class="crm-transaction-links"></th></tr></thead></table>'; ?>

  </div>
</div>
<?php endif; ?>

<?php echo '
<script type="text/javascript">
cj( function() {
  cj().crmAccordions();
  cj(\'#_qf_BatchTransaction_submit-top, #_qf_BatchTransaction_submit-botttom\').click(function() {
    cj(\'.crm-batch_transaction_search-accordion:not(.collapsed)\').crmAccordionToggle();
  });
  var batchStatus = '; ?>
<?php echo $this->_tpl_vars['statusID']; ?>
<?php echo ';
  // build transaction listing only for open batches
  if (batchStatus == 1) {
    var paymentInstrumentID = '; ?>
<?php if ($this->_tpl_vars['paymentInstrumentID'] != null): ?><?php echo $this->_tpl_vars['paymentInstrumentID']; ?>
<?php else: ?>'null'<?php endif; ?><?php echo ';
    if (paymentInstrumentID != \'null\') {
      buildTransactionSelectorAssign( true );
    }
    else {
      buildTransactionSelectorAssign( false );
    }
    buildTransactionSelectorRemove();
    cj(\'#_qf_BatchTransaction_submit-botttom, #_qf_BatchTransaction_submit-top\').click( function() {
      buildTransactionSelectorAssign( true );
      return false;
    });

    cj("#trans_assign").attr(\'disabled\',true);
    cj("#trans_remove").attr(\'disabled\',true);
    cj(\'#crm-transaction-selector-assign #toggleSelect\').click( function() {
      enableActions(\'x\');
    });
    cj(\'#crm-transaction-selector-remove #toggleSelects\').click( function() {
      enableActions(\'y\');
    });
    cj(\'#Go\').click( function() {
      return selectAction("trans_assign","toggleSelect", "crm-transaction-selector-assign input[id^=\'mark_x_\']");
    });
    cj(\'#GoRemove\').click( function() {
      return selectAction("trans_remove","toggleSelects", "crm-transaction-selector-remove input[id^=\'mark_y_\']");
    });
    cj(\'#Go\').click( function() {
      if (cj("#trans_assign" ).val() != "" && cj("input[id^=\'mark_x_\']").is(\':checked\')) {
        bulkAssignRemove(\'Assign\');
      }
      return false;
    });
    cj(\'#GoRemove\').click( function() {
      if (cj("#trans_remove" ).val() != "" && cj("input[id^=\'mark_y_\']").is(\':checked\')) {
        bulkAssignRemove(\'Remove\');
      }
      return false;
    });
    cj("#crm-transaction-selector-assign input[id^=\'mark_x_\']").click( function() {
      enableActions(\'x\');
    });
    cj("#crm-transaction-selector-remove input[id^=\'mark_y_\']").click( function() {
      enableActions(\'y\');
    });

    cj("#crm-transaction-selector-assign #toggleSelect").click( function() {
      if (cj("#crm-transaction-selector-assign #toggleSelect").is(\':checked\')) {
        cj("#crm-transaction-selector-assign input[id^=\'mark_x_\']").prop(\'checked\',true);
      }
      else {
        cj("#crm-transaction-selector-assign input[id^=\'mark_x_\']").prop(\'checked\',false);
      }
    });
    cj("#crm-transaction-selector-remove #toggleSelects").click( function() {
      if (cj("#crm-transaction-selector-remove #toggleSelects").is(\':checked\')) {
        cj("#crm-transaction-selector-remove input[id^=\'mark_y_\']").prop(\'checked\',true);
      }
      else {
        cj("#crm-transaction-selector-remove input[id^=\'mark_y_\']").prop(\'checked\',false);
      }
    });
  }
  else {
    buildTransactionSelectorRemove();
  }
});

function enableActions( type ) {
  if (type == \'x\') {
    cj("#trans_assign").attr(\'disabled\',false);
  }
  else {
    cj("#trans_remove").attr(\'disabled\',false);
  }
}

function buildTransactionSelectorAssign(filterSearch) {
  var columns = \'\';
  var sourceUrl = '; ?>
'<?php echo CRM_Utils_System::crmURL(array('p' => "civicrm/ajax/rest",'h' => 0,'q' => "className=CRM_Financial_Page_AJAX&fnName=getFinancialTransactionsList&snippet=4&context=financialBatch&entityID=".($this->_tpl_vars['entityID'])."&notPresent=1&statusID=".($this->_tpl_vars['statusID'])), $this);?>
'<?php echo ';
  if ( filterSearch ) {
    sourceUrl = sourceUrl+"&search=1";
    var ZeroRecordText = \'<div class="status messages">'; ?>
<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>No Contributions found for your search criteria.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?><?php echo '</li></ul></div>\';
  }

  crmBatchSelector1 = cj(\'#crm-transaction-selector-assign\').dataTable({
  "bDestroy"   : true,
  "bFilter"    : false,
  "bAutoWidth" : false,
  "aaSorting"  : [[5, \'desc\']],
  "aoColumns"  : [
    {sClass:\'crm-transaction-checkbox\', bSortable:false},
    {sClass:\'crm-contact-type\', bSortable:false},
    {sClass:\'crm-contact-name\'},
    {sClass:\'crm-amount\'},
    {sClass:\'crm-trxnID\'},
    {sClass:\'crm-received\'},
    {sClass:\'crm-payment-method\'},
    {sClass:\'crm-status\'},
    {sClass:\'crm-type\'},
    {sClass:\'crm-transaction-links\', bSortable:false}
  ],
  "bProcessing": true,
  "asStripClasses" : [ "odd-row", "even-row" ],
  "sPaginationType": "full_numbers",
  "sDom"       : \'<"crm-datatable-pager-top"lfp>rt<"crm-datatable-pager-bottom"ip>\',
  "bServerSide": true,
  "bJQueryUI": true,
  "sAjaxSource": sourceUrl,
  "iDisplayLength": 25,
  "oLanguage": {
    "sZeroRecords":  ZeroRecordText,
    "sProcessing":    '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Processing...<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sLengthMenu":    '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Show _MENU_ entries<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sInfo":          '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing _START_ to _END_ of _TOTAL_ entries<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sInfoEmpty":     '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing 0 to 0 of 0 entries<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sInfoFiltered":  '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>(filtered from _MAX_ total entries)<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sSearch":        '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Search:<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "oPaginate": {
      "sFirst":    '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>First<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
      "sPrevious": '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Previous<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
      "sNext":     '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Next<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
      "sLast":     '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Last<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo '
    }
  },
  "fnServerData": function ( sSource, aoData, fnCallback ) {
    if ( filterSearch ) {
      cj(\'#searchForm :input\').each(function() {
        if (cj(this).val()) {
          aoData.push(
            {name:cj(this).attr(\'id\'), value: cj(this).val()}
          );
          cj(\':radio, :checkbox\').each(function() {
            if (cj(this).is(\':checked\')) {
              aoData.push( { name: cj(this).attr(\'name\'), value: cj(this).val() } );
            }
          });
        }
      });
    }
    cj.ajax({
      "dataType": \'json\',
      "type": "POST",
      "url": sSource,
      "data": aoData,
      "success": fnCallback
    });
  }
});
}

function buildTransactionSelectorRemove( ) {
  var columns = \'\';
  var sourceUrl = '; ?>
'<?php echo CRM_Utils_System::crmURL(array('p' => "civicrm/ajax/rest",'h' => 0,'q' => "className=CRM_Financial_Page_AJAX&fnName=getFinancialTransactionsList&snippet=4&context=financialBatch&entityID=".($this->_tpl_vars['entityID'])."&statusID=".($this->_tpl_vars['statusID'])), $this);?>
'<?php echo ';

  crmBatchSelector = cj(\'#crm-transaction-selector-remove\').dataTable({
  "bDestroy"   : true,
  "bFilter"    : false,
  "bAutoWidth" : false,
  "aaSorting"  : [[5, \'desc\']],
  "aoColumns"  : [
    {sClass:\'crm-transaction-checkbox\', bSortable:false},
    {sClass:\'crm-contact-type\', bSortable:false},
    {sClass:\'crm-contact-name\'},
    {sClass:\'crm-amount\'},
    {sClass:\'crm-trxnID\'},
    {sClass:\'crm-received\'},
    {sClass:\'crm-payment-method\'},
    {sClass:\'crm-status\'},
    {sClass:\'crm-type\'},
    {sClass:\'crm-transaction-links\', bSortable:false}
  ],
  "bProcessing": true,
  "asStripClasses" : [ "odd-row", "even-row" ],
  "sPaginationType": "full_numbers",
  "sDom"       : \'<"crm-datatable-pager-top"lfp>rt<"crm-datatable-pager-bottom"ip>\',
  "bServerSide": true,
  "bJQueryUI": true,
  "sAjaxSource": sourceUrl,
  "iDisplayLength": 25,
  "oLanguage": {
    "sProcessing":    '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Processing...<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sLengthMenu":    '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Show _MENU_ entries<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sInfo":          '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing _START_ to _END_ of _TOTAL_ entries<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sInfoEmpty":     '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Showing 0 to 0 of 0 entries<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sInfoFiltered":  '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>(filtered from _MAX_ total entries)<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "sSearch":        '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Search:<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
    "oPaginate": {
      "sFirst":    '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>First<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
      "sPrevious": '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Previous<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
      "sNext":     '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Next<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo ',
      "sLast":     '; ?>
"<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Last<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>"<?php echo '
    }
  },
  "fnServerData": function (sSource, aoData, fnCallback) {
    cj.ajax({
      "dataType": \'json\',
      "type": "POST",
      "url": sSource,
      "data": aoData,
      "success": fnCallback
    });
  }
});
}

function selectAction( id, toggleSelectId, checkId ) {
  if (cj("#"+ id ).is(\':disabled\')) {
    return false;
  }
  else if (!cj("#" + toggleSelectId).is(\':checked\') && !cj("#" + checkId).is(\':checked\') && cj("#" + id).val() != "") {
    CRM.alert ('; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Please select one or more contributions for this action.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo ');
    return false;
  }
  else if (cj("#" + id).val() == "") {
    CRM.alert ('; ?>
'<?php $this->_tag_stack[] = array('ts', array('escape' => 'js')); $_block_repeat=true;smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], null, $this, $_block_repeat);while ($_block_repeat) { ob_start(); ?>Please select an action from the drop-down menu.<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_ts($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>'<?php echo ');
    return false;
  }
}

function bulkAssignRemove( action ) {
  var postUrl = '; ?>
"<?php echo CRM_Utils_System::crmURL(array('p' => 'civicrm/ajax/rest','h' => 0,'q' => "className=CRM_Financial_Page_AJAX&fnName=bulkAssignRemove&entityID=".($this->_tpl_vars['entityID'])), $this);?>
"<?php echo ';
  var fids = [];
  if (action == \'Assign\') {
    cj("input[id^=\'mark_x_\']:checked").each( function () {
      var a = cj(this).attr(\'id\');
      fids.push(a);
    });
  }
  if (action == \'Remove\') {
    cj("input[id^=\'mark_y_\']:checked").each( function () {
      var a = cj(this).attr(\'id\');
      fids.push(a);
    });
  }
  cj.post(postUrl, { ID: fids, action:action }, function(data) {
    //this is custom status set when record update success.
    if (data.status == \'record-updated-success\') {
      buildTransactionSelectorAssign( true );
      buildTransactionSelectorRemove();
      batchSummary('; ?>
<?php echo $this->_tpl_vars['entityID']; ?>
<?php echo ');
    }
    else {
      CRM.alert(data.status);
    }
  }, \'json\');
}
</script>
'; ?>

<?php $_block_content = ob_get_contents(); ob_end_clean(); $_block_repeat=false;echo smarty_block_crmScope($this->_tag_stack[count($this->_tag_stack)-1][1], $_block_content, $this, $_block_repeat); }  array_pop($this->_tag_stack); ?>